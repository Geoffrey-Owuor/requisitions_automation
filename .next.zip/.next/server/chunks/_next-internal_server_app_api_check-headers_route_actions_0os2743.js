module.exports=[55658,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_check-headers_route_actions_0os2743.js.map