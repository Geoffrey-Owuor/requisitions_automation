module.exports=[2990,e=>{"use strict";var t=e.i(71917);function i(e,t){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 40%; border-bottom: 1px solid #f7f0f0;">${e}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${t||"—"}</td>
    </tr>`}function r(e,t,i,r){let o=(t||"").toLowerCase(),a="#854d0e",n="#fef9c3",s="1px solid #854d0e";return(o.includes("approved")||o.includes("accepted"))&&(a="#166534",n="#dcfce7",s="1px solid #166534"),(o.includes("declined")||o.includes("rejected"))&&(a="#991b1b",n="#fee2e2",s="1px solid #991b1b"),`
    <div style="border-radius: 12px; border: 1px solid #f0e6e6; padding: 14px 16px; background-color: #ffffff;">
      <p style="margin: 0 0 2px; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase; letter-spacing: 1px;">${e}</p>
      <p style="margin: 0 0 8px; font-size: 13px; color: #1a0f0f; font-weight: 600;">${i||"Awaiting Assignment"}</p>
      <span style="padding: 3px 9px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${a}; background-color: ${n}; border: ${s}; text-transform: uppercase; display: inline-block;">${t||"Pending"}</span>
      <p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 6px 10px; border-radius: 8px; border: 1px dashed #eee;">"${r||"N/A"}"</p>
    </div>
  `}e.s(["ITRequisitionTemplate",0,function({requestId:e,message:o,title:a,role:n,emailData:s,reviewLink:d}){let l=(0,t.dateFormatter)(s.datesubmitted),p=(0,t.dateFormatter)(s.requisitiondate),u=(0,t.dateFormatter)(s.datejoining);return`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">

        <!-- Header: solid background avoids Outlook gradient rendering issues -->
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
          <table width="100%">
            <tr>
              <td style="vertical-align: middle;">
                <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.85;">IT Department</p>
                <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${a}</h2>
              </td>
              <td style="text-align: right; vertical-align: middle;">
                <div style="display: inline-block; background-color: #7f1d1d; border-radius: 12px; padding: 8px 14px;">
                  <p style="margin: 0; font-size: 11px; font-weight: 700; color: #f2d7d5; letter-spacing: 1px;">IT REQ</p>
                </div>
              </td>
            </tr>
          </table>
        </div>

        <div style="padding: 30px 24px;">

          <!-- Message box: explicit white avoids Outlook dark-mode unpredictability -->
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #dbeafe;">
            <p style="margin: 0; font-size: 15px; color: #1e293b; line-height: 1.6;">${o}</p>
          </div>

          <!-- Submission meta strip -->
          <div style="background-color: #fdf2f2; border-radius: 12px; padding: 12px 16px; margin-bottom: 24px; border: 1px solid #f2d7d5;">
            <table width="100%">
              <tr>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Submitted by</td>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; text-align: right;">Date Submitted</td>
              </tr>
              <tr>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px;">${s.submittername||"—"}</td>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px; text-align: right;">${l}</td>
              </tr>
            </table>
          </div>

          <!-- Employee Information -->
          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Employee Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${i("Employee Name",s.employeename)}
              ${i("Staff Number",s.employeestaffnumber)}
              ${i("Department",s.employeedepartment)}
              ${i("Date Joining",u)}
              ${i("Requisition Date",p)}
            </table>
          </div>

          <!-- Equipment Details: dark solid box (same gradient-avoidance fix as Travel) -->
          <div style="background-color: #0f172a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(30,58,138,0.3);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #f87171; text-transform: uppercase; letter-spacing: 2px;">Equipment Details</p>
            <table width="100%">
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8;">Request Type</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${s.replacementnew||"—"}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8; vertical-align: top;">Requirements</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${s.requirements||"—"}</td>
              </tr>
              ${s.otherrequirements?`<tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 12px;">
                  <p style="margin: 0 0 4px; font-size: 10px; font-weight: 700; color: #f87171; text-transform: uppercase; letter-spacing: 1px;">Additional Requirements</p>
                  <p style="margin: 0; font-size: 12px; color: #cbd5e1; line-height: 1.5;">${s.otherrequirements}</p>
                </td>
              </tr>`:""}
            </table>
          </div>

          <!-- Approval Workflow -->
          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>

          <!-- Two-column grid via table for Outlook compatibility -->
          <table width="100%" style="border-collapse: separate; border-spacing: 0 0; margin-bottom: 24px;">
            <tr>
              <td width="49%" style="vertical-align: top; padding-right: 8px;">
                ${r("Head of Department",s.hodapprovalstatus,s.hodapprover,s.hodcomments)}
              </td>
              <td width="2%"></td>
              <td width="49%" style="vertical-align: top;">
                ${r("IT Department",s.itapprovalstatus,s.itapprover,s.itcomments)}
              </td>
            </tr>
          </table>

          <!-- CTA Button -->
          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==n?"display: inline-block;":"display: none;"}">
              <a href="https://192.168.0.155/itapproval/${e}${d??""}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
          </div>

        </div>

        <!-- Footer: explicit white avoids near-white Outlook dark-mode issues -->
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #64748b; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | IT Requisition</p>
        </div>

      </div>
    </div>
  `}])},66029,e=>e.a(async(t,i)=>{try{var r=e.i(47540),o=e.i(62294),a=e.i(44732),n=e.i(2990),s=t([o]);[o]=s.then?(await s)():s;let l=`
  SELECT
  request_created_at AS datesubmitted,
  submitter_name AS submittername,
  employee_name AS employeename,
  employee_staff_number AS employeestaffnumber,
  employee_department AS employeedepartment,
  replacement_new AS replacementnew,
  requirements,
  other_requirements AS otherrequirements,
  requisition_date AS requisitiondate,
  date_joining AS datejoining,
  hod_approver_name AS hodapprover,
  hod_approver_status AS hodapprovalstatus,
  hod_approver_comments AS hodcomments,
  it_approver_name AS itapprover,
  it_approver_status AS itapprovalstatus,
  it_approver_comments AS itcomments
  FROM it_requisitions WHERE request_id = $1
`,p=(0,r.cache)(async e=>(await (0,o.query)(l,[e]))[0]);async function d({to:e,requestId:t,message:i,title:r,role:o,reviewLink:s}){let l=await p(t),u=(0,n.ITRequisitionTemplate)({requestId:t,title:r,message:i,role:o,emailData:l,reviewLink:s});await (0,a.sendEmail)({from:process.env.IT_EMAIL_SENDER,to:e,subject:r,html:u})}e.s(["ITEmailSender",0,d]),i()}catch(e){i(e)}},!1),49101,e=>e.a(async(t,i)=>{try{var r=e.i(89171),o=e.i(25725),a=e.i(66029),n=e.i(62294),s=t([o,a,n]);async function d(e){let t=await (0,o.loadITArray)();try{let{formData:i,submittedBy:o}=await e.json(),{name:s,email:d}=o;if(!s||!d)return r.NextResponse.json({message:"Cannot verify the user trying to make this requisition"},{status:401});let{employeeName:l,department:p,staffNumber:u,requestType:c,hodApprover:f,requirements:m,otherRequirements:g,requisitionDate:h,dateJoining:x}=i;if([l,p,u,c,f,g,h,x].some(e=>!e)||!m||0===m.length)return r.NextResponse.json({message:"Your requisition is missing some required form fields"},{status:400});let b=await (0,n.query)(`
      SELECT hod_uuid AS uuid, 
      hod_email AS email
      FROM hod_array WHERE hod_name = $1 LIMIT 1
      `,[f]);if(0===b.length)return r.NextResponse.json({message:"Could not find the selected HOD approver in current approval workflow, contact the admin for support"},{status:404});let y=b[0].uuid,v=b[0].email,w=m.join(", "),R=`
  INSERT INTO it_requisitions
  (submitter_email, submitter_name, employee_name, employee_department, employee_staff_number,
   replacement_new, requirements, other_requirements, requisition_date, date_joining, hod_approver_name, hod_approver_email)
   VALUES
   ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
   RETURNING request_id
  `,q=[d,s,l,p,u,c,w,g,h,x,f,v],_=(await (0,n.query)(R,q))[0].request_id;if(v===d){let e=`
        UPDATE it_requisitions
        SET
        hod_approval_date = CURRENT_TIMESTAMP,
        hod_approver_email = $1,
        hod_approver_status = $2,
        hod_approver_comments = $3
        WHERE request_id = $4
        `,i=[v,"approved","Automatic HOD Approval",_];await (0,n.query)(e,i),t.forEach(e=>{(0,a.ITEmailSender)({to:e.email,requestId:_,message:"A new IT Requisition has been submitted and requires your review",title:"Action Required: New IT Requisition",role:"IT",reviewLink:`?token=${e.uuid}&stage=it`})}),(0,a.ITEmailSender)({to:d,requestId:_,message:"Your IT requisition has been submitted successfully and forwaded to IT for review",title:"Update: IT Requisition Submitted Successfully",role:"user"})}else(0,a.ITEmailSender)({to:v,requestId:_,message:"A new IT Requisition has been submitted and requires your review",title:"Action Required: New IT Requisition",role:"HOD",reviewLink:`?token=${y}&stage=hod`}),(0,a.ITEmailSender)({to:d,requestId:_,message:"Your IT requisition has been submitted successfully and forwaded to the HOD for review",title:"Update: IT Requisition Submitted Successfully",role:"user"});return r.NextResponse.json({message:"Your IT requisition has been submitted successfully, you will receive a confirmation email shortly"},{status:200})}catch(e){return console.error("Error while trying to submit the requisition",e),r.NextResponse.json({message:"An error occurred while trying to submit this requisition"},{status:500})}}[o,a,n]=s.then?(await s)():s,e.s(["POST",0,d]),i()}catch(e){i(e)}},!1),28806,e=>e.a(async(t,i)=>{try{var r=e.i(47909),o=e.i(74017),a=e.i(96250),n=e.i(59756),s=e.i(61916),d=e.i(74677),l=e.i(69741),p=e.i(16795),u=e.i(87718),c=e.i(95169),f=e.i(47587),m=e.i(66012),g=e.i(70101),h=e.i(26937),x=e.i(10372),b=e.i(93695);e.i(52474);var y=e.i(220),v=e.i(49101),w=t([v]);[v]=w.then?(await w)():w;let q=new r.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/itrequisition/submitrequisition/route",pathname:"/api/itrequisition/submitrequisition",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/itrequisition/submitrequisition/route.ts",nextConfigOutput:"",userland:v,...{}}),{workAsyncStorage:_,workUnitAsyncStorage:E,serverHooks:A}=q;async function R(e,t,i){i.requestMeta&&(0,n.setRequestMeta)(e,i.requestMeta),q.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/itrequisition/submitrequisition/route";r=r.replace(/\/index$/,"")||"/";let a=await q.prepare(e,t,{srcPage:r,multiZoneDraftMode:!1});if(!a)return t.statusCode=400,t.end("Bad Request"),null==i.waitUntil||i.waitUntil.call(i,Promise.resolve()),null;let{buildId:v,deploymentId:w,params:R,nextConfig:_,parsedUrl:E,isDraftMode:A,prerenderManifest:T,routerServerContext:S,isOnDemandRevalidate:$,revalidateOnlyGenerated:I,resolvedPathname:k,clientReferenceManifest:C,serverActionsManifest:N}=a,O=(0,l.normalizeAppPath)(r),D=!!(T.dynamicRoutes[O]||T.routes[k]),H=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,E,!1):t.end("This page could not be found"),null);if(D&&!A){let e=!!T.routes[k],t=T.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(_.adapterPath)return await H();throw new b.NoFallbackError}}let P=null;!D||q.isDev||A||(P=k,P="/index"===P?"/":P);let z=!0===q.isDev||!D,M=D&&!z;N&&C&&(0,d.setManifestsSingleton)({page:r,clientReferenceManifest:C,serverActionsManifest:N});let U=e.method||"GET",j=(0,s.getTracer)(),F=j.getActiveScopeSpan(),L=!!(null==S?void 0:S.isWrappedByNextServer),B=!!(0,n.getRequestMeta)(e,"minimalMode"),K=(0,n.getRequestMeta)(e,"incrementalCache")||await q.getIncrementalCache(e,_,T,B);null==K||K.resetRequestCache(),globalThis.__incrementalCache=K;let W={params:R,previewProps:T.preview,renderOpts:{experimental:{authInterrupts:!!_.experimental.authInterrupts},cacheComponents:!!_.cacheComponents,supportsDynamicResponse:z,incrementalCache:K,cacheLifeProfiles:_.cacheLife,waitUntil:i.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,i,r,o)=>q.onRequestError(e,t,r,o,S)},sharedContext:{buildId:v,deploymentId:w}},Y=new p.NodeNextRequest(e),G=new p.NodeNextResponse(t),V=u.NextRequestAdapter.fromNodeNextRequest(Y,(0,u.signalFromNodeResponse)(t));try{let a,n=async e=>q.handle(V,W).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let i=j.getRootSpanAttributes();if(!i)return;if(i.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${i.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=i.get("next.route");if(o){let t=`${U} ${o}`;e.setAttributes({"next.route":o,"http.route":o,"next.span_name":t}),e.updateName(t),a&&a!==e&&(a.setAttribute("http.route",o),a.updateName(t))}else e.updateName(`${U} ${r}`)}),d=async a=>{var s,d;let l=async({previousCacheEntry:o})=>{try{if(!B&&$&&I&&!o)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await n(a);e.fetchMetrics=W.renderOpts.fetchMetrics;let s=W.renderOpts.pendingWaitUntil;s&&i.waitUntil&&(i.waitUntil(s),s=void 0);let d=W.renderOpts.collectedTags;if(!D)return await (0,m.sendResponse)(Y,G,r,W.renderOpts.pendingWaitUntil),null;{let e=await r.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(r.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let i=void 0!==W.renderOpts.collectedRevalidate&&!(W.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&W.renderOpts.collectedRevalidate,o=void 0===W.renderOpts.collectedExpire||W.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:W.renderOpts.collectedExpire;return{value:{kind:y.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:i,expire:o}}}}catch(t){throw(null==o?void 0:o.isStale)&&await q.onRequestError(e,t,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:$})},!1,S),t}},p=await q.handleResponse({req:e,nextConfig:_,cacheKey:P,routeKind:o.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:$,revalidateOnlyGenerated:I,responseGenerator:l,waitUntil:i.waitUntil,isMinimalMode:B});if(!D)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==y.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(d=p.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",$?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,g.fromNodeOutgoingHttpHeaders)(p.value.headers);return B&&D||u.delete(x.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,h.getCacheControlHeader)(p.cacheControl)),await (0,m.sendResponse)(Y,G,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};L&&F?await d(F):(a=j.getActiveScopeSpan(),await j.withPropagatedContext(e.headers,()=>j.trace(c.BaseServerSpan.handleRequest,{spanName:`${U} ${r}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},d),void 0,!L))}catch(t){if(t instanceof b.NoFallbackError||await q.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:$})},!1,S),D)throw t;return await (0,m.sendResponse)(Y,G,new Response(null,{status:500})),null}}e.s(["handler",0,R,"patchFetch",0,function(){return(0,a.patchFetch)({workAsyncStorage:_,workUnitAsyncStorage:E})},"routeModule",0,q,"serverHooks",0,A,"workAsyncStorage",0,_,"workUnitAsyncStorage",0,E]),i()}catch(e){i(e)}},!1)];

//# sourceMappingURL=_0f8~gnx._.js.map