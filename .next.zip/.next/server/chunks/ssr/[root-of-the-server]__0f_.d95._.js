module.exports=[99450,a=>{a.v("/_next/static/media/hotpoint_icon.03v1kd-iqopka.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},54442,a=>{a.v("/_next/static/media/form_image.016.01-z~7ilt.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},91962,a=>{a.v("/_next/static/media/hotpoint_logo.14-vmxudg2qno.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,a=>{a.v("/_next/static/media/hotpoint_black_logo.0m41_m1z8uhzw.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},11985,a=>{a.v("/_next/static/media/it_form_image.0lz1c.hirvfk_.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},64240,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))},88947,(a,b,c)=>{b.exports=a.x("stream",()=>require("stream"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},66680,(a,b,c)=>{b.exports=a.x("node:crypto",()=>require("node:crypto"))},21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},1515,a=>{"use strict";let b={src:a.i(99450).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAMBAAQyCQI7dBQFi4YXBqF9FQaVQgsDS4MWBpxyFAaGAEILA061IAnfyyQK/MokCvm8IQnmZBIFdsgjCvarHgnTAJsbCLzKJAr7fRYGlmMRBXJbEARpTA4DWccjCvarHgnSALEfCdjDIgryVQ8EY6weCNKkHQjHVA4EY8cjCvarHwnSALIfCdrCIgnvTQ0EWJ4cCMGWGge2Ug4EYccjCverHwnSALMgCdvBIgruSQ0EU3EUBYZzFAaJkRoHscslC/2aGwi8ALMfCdzBIgruYhEFc8UjCvPNJAr+zCUK/bUgCeBEDARRAGIQBXRqEgV+NgkDPWwTBYJwEwWJZxIFfDEIAjoEAQAETr5TfppXlUsAAAAASUVORK5CYII="},c={src:a.i(54442).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYFha9ND51fmHZ9NTcntjUCRmFk4uq2xNzAI3jCztmkPycAAAAAElFTkSuQmCC"},d={src:a.i(91962).default,width:800,height:360,blurWidth:8,blurHeight:4,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAZElEQVR42k3MMQqFQBAD0GTmy+5fFe08gaUHsBPsLUUEa1vR+4MRLBx4DCQQAKglSTQgI6CHXIL8YeaHuV/ufg6p3NsQd2Xnk9FsAcmOtN5lSMXa/LJJxSazuhHfC+QzG6V6pRv3AAds+3z7uwAAAABJRU5ErkJggg=="},e={src:a.i(41535).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAk0lEQVR42j3QLwvCQBiA8Tf4qRQ/gSCIRaOYrComMRgEMWuy+BEsJovJrmVsgy0tbrDBxtgf9hy8W/jBcfdwd7wiIj0McMEDV4xwxwkyhocSOQLskOJvgjcK3LDGCnMNfiawEGOpG19dd4GNCDN88MICWRs4CDHVT53xRKXPi6vBBglqPfQxMcEWBwxx1Bv26JsRNFZmKZZ3JF37AAAAAElFTkSuQmCC"},f={src:a.i(11985).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYUlyyML9odl7RxLiU/qTM9uiUlsiU3rxyAJDeCy/80jrPAAAAAElFTkSuQmCC"};a.s(["assets",0,{hotpoint_logo:b,form_image:c,hotpoint_background:d,hotpoint_black_logo:e,it_form_image:f},"dateFormatter",0,function(a){return a?new Date(a).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"—"}],1515)},91677,a=>{"use strict";var b=a.i(7997);a.s(["default",0,()=>(0,b.jsx)("footer",{className:"relative z-10",children:(0,b.jsx)("div",{className:"mx-auto flex max-w-6xl flex-col items-center justify-center gap-6 p-6 sm:flex-row",children:(0,b.jsxs)("p",{className:"text-[13px] text-slate-500",children:["© ",new Date().getFullYear()," Hotpoint Appliances Ltd · Internal Use Only"]})})})])},46706,a=>{"use strict";var b=a.i(7997),c=a.i(91677);a.s(["default",0,({children:a})=>(0,b.jsxs)("div",{className:"flex h-full w-full flex-col",children:[(0,b.jsx)("main",{className:"mx-auto w-full max-w-7xl flex-1",children:a}),(0,b.jsx)(c.default,{})]})])},23862,a=>a.a(async(b,c)=>{try{let b=await a.y("pg-587764f78a6c7a9c");a.n(b),c()}catch(a){c(a)}},!0),66879,a=>a.a(async(b,c)=>{try{let g;var d=a.i(23862),e=b([d]);[d]=e.then?(await e)():e;let h={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function f(a,b){let c=await g.connect();try{return(await c.query(a,b)).rows}finally{c.release()}}g=new d.Pool(h),a.s(["pool",0,g,"query",0,f]),c()}catch(a){c(a)}},!1),67726,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/DashboardSidebar.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/DashboardSidebar.tsx <module evaluation>","default")},94648,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/DashboardSidebar.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/DashboardSidebar.tsx","default")},93931,a=>{"use strict";a.i(67726);var b=a.i(94648);a.n(b)},5463,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/MobileHeader.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/MobileHeader.tsx <module evaluation>","default")},6369,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/MobileHeader.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/MobileHeader.tsx","default")},47487,a=>{"use strict";a.i(5463);var b=a.i(6369);a.n(b)},5675,a=>{"use strict";var b=a.i(7997),c=a.i(93931),d=a.i(47487);a.s(["default",0,({children:a})=>(0,b.jsxs)("div",{className:"min-h-screen bg-linear-to-br from-red-950 via-red-950 to-red-900",children:[(0,b.jsx)(d.default,{}),(0,b.jsx)(c.default,{}),(0,b.jsx)("div",{id:"dashboard-wrapper",className:"layout-scrollbar fixed top-16 right-0 bottom-0 left-0 rounded-t-3xl bg-white sm:rounded-t-2xl sm:rounded-tr-none lg:top-0 lg:left-20",children:(0,b.jsx)("div",{className:"flex h-full w-full flex-col",children:a})})]})])},96719,a=>{"use strict";a.s(["UserProvider",()=>c,"useUser",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call UserProvider() from the server but UserProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx <module evaluation>","UserProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx <module evaluation>","useUser")},49390,a=>{"use strict";a.s(["UserProvider",()=>c,"useUser",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call UserProvider() from the server but UserProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx","UserProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx","useUser")},51016,a=>{"use strict";a.i(96719);var b=a.i(49390);a.n(b)},25489,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx <module evaluation>","default")},11152,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx","default")},44908,a=>{"use strict";a.i(25489);var b=a.i(11152);a.n(b)},90849,a=>{"use strict";var b=a.i(1515);function c(a,b){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 40%; border-bottom: 1px solid #f7f0f0;">${a}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${b||"—"}</td>
    </tr>`}function d(a,b,c,d){let e=(b||"").toLowerCase(),f="#854d0e",g="#fef9c3",h="1px solid #854d0e";return(e.includes("approved")||e.includes("accepted"))&&(f="#166534",g="#dcfce7",h="1px solid #166534"),(e.includes("declined")||e.includes("rejected"))&&(f="#991b1b",g="#fee2e2",h="1px solid #991b1b"),`
    <div style="border-radius: 12px; border: 1px solid #f0e6e6; padding: 14px 16px; background-color: #ffffff;">
      <p style="margin: 0 0 2px; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase; letter-spacing: 1px;">${a}</p>
      <p style="margin: 0 0 8px; font-size: 13px; color: #1a0f0f; font-weight: 600;">${c||"Awaiting Assignment"}</p>
      <span style="padding: 3px 9px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${f}; background-color: ${g}; border: ${h}; text-transform: uppercase; display: inline-block;">${b||"Pending"}</span>
      <p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 6px 10px; border-radius: 8px; border: 1px dashed #eee;">"${d||"N/A"}"</p>
    </div>
  `}a.s(["ITRequisitionTemplate",0,function({requestId:a,message:e,title:f,role:g,emailData:h,reviewLink:i}){let j=(0,b.dateFormatter)(h.datesubmitted),k=(0,b.dateFormatter)(h.requisitiondate),l=(0,b.dateFormatter)(h.datejoining);return`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">

        <!-- Header: solid background avoids Outlook gradient rendering issues -->
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
          <table width="100%">
            <tr>
              <td style="vertical-align: middle;">
                <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.85;">IT Department</p>
                <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${f}</h2>
              </td>
              <td style="text-align: right; vertical-align: middle;">
                <div style="display: inline-block; background-color: #7f1d1d; border-radius: 12px; padding: 8px 14px;">
                  <p style="margin: 0; font-size: 11px; font-weight: 700; color: #f2d7d5; letter-spacing: 1px;">IT REQ</p>
                </div>
              </td>
            </tr>
          </table>
        </div>

        <div style="padding: 30px 24px;">

          <!-- Message box: explicit white avoids Outlook dark-mode unpredictability -->
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #dbeafe;">
            <p style="margin: 0; font-size: 15px; color: #1e293b; line-height: 1.6;">${e}</p>
          </div>

          <!-- Submission meta strip -->
          <div style="background-color: #fdf2f2; border-radius: 12px; padding: 12px 16px; margin-bottom: 24px; border: 1px solid #f2d7d5;">
            <table width="100%">
              <tr>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Submitted by</td>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; text-align: right;">Date Submitted</td>
              </tr>
              <tr>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px;">${h.submittername||"—"}</td>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px; text-align: right;">${j}</td>
              </tr>
            </table>
          </div>

          <!-- Employee Information -->
          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Employee Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${c("Employee Name",h.employeename)}
              ${c("Staff Number",h.employeestaffnumber)}
              ${c("Department",h.employeedepartment)}
              ${c("Date Joining",l)}
              ${c("Requisition Date",k)}
            </table>
          </div>

          <!-- Equipment Details: dark solid box (same gradient-avoidance fix as Travel) -->
          <div style="background-color: #0f172a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(30,58,138,0.3);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #f87171; text-transform: uppercase; letter-spacing: 2px;">Equipment Details</p>
            <table width="100%">
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8;">Request Type</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${h.replacementnew||"—"}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8; vertical-align: top;">Requirements</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${h.requirements||"—"}</td>
              </tr>
              ${h.otherrequirements?`<tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 12px;">
                  <p style="margin: 0 0 4px; font-size: 10px; font-weight: 700; color: #f87171; text-transform: uppercase; letter-spacing: 1px;">Additional Requirements</p>
                  <p style="margin: 0; font-size: 12px; color: #cbd5e1; line-height: 1.5;">${h.otherrequirements}</p>
                </td>
              </tr>`:""}
            </table>
          </div>

          <!-- Approval Workflow -->
          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>

          <!-- Two-column grid via table for Outlook compatibility -->
          <table width="100%" style="border-collapse: separate; border-spacing: 0 0; margin-bottom: 24px;">
            <tr>
              <td width="49%" style="vertical-align: top; padding-right: 8px;">
                ${d("Head of Department",h.hodapprovalstatus,h.hodapprover,h.hodcomments)}
              </td>
              <td width="2%"></td>
              <td width="49%" style="vertical-align: top;">
                ${d("IT Department",h.itapprovalstatus,h.itapprover,h.itcomments)}
              </td>
            </tr>
          </table>

          <!-- CTA Button -->
          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==g?"display: inline-block;":"display: none;"}">
              <a href="https://192.168.0.155/itapproval/${a}${i??""}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
          </div>

        </div>

        <!-- Footer: explicit white avoids near-white Outlook dark-mode issues -->
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #64748b; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | IT Requisition</p>
        </div>

      </div>
    </div>
  `}])},69083,a=>a.a(async(b,c)=>{try{var d=a.i(717),e=a.i(66879),f=a.i(35723),g=a.i(90849),h=b([e]);[e]=h.then?(await h)():h;let j=`
  SELECT
  request_created_at AS datesubmitted,
  submitter_name AS submittername,
  employee_name AS employeename,
  employee_staff_number AS employeestaffnumber,
  employee_department AS employeedepartment,
  replacement_new AS replacementnew,
  requirements,
  other_requirements AS otherrequirements,
  requisition_date AS requisitiondate,
  date_joining AS datejoining,
  hod_approver_name AS hodapprover,
  hod_approver_status AS hodapprovalstatus,
  hod_approver_comments AS hodcomments,
  it_approver_name AS itapprover,
  it_approver_status AS itapprovalstatus,
  it_approver_comments AS itcomments
  FROM it_requisitions WHERE request_id = $1
`,k=(0,d.cache)(async a=>(await (0,e.query)(j,[a]))[0]);async function i({to:a,requestId:b,message:c,title:d,role:e,reviewLink:h}){let j=await k(b),l=(0,g.ITRequisitionTemplate)({requestId:b,title:d,message:c,role:e,emailData:j,reviewLink:h});await (0,f.sendEmail)({from:process.env.IT_EMAIL_SENDER,to:a,subject:d,html:l})}a.s(["ITDataQuery",0,j,"ITEmailSender",0,i]),c()}catch(a){c(a)}},!1),26758,a=>{a.v("/_next/static/media/favicon.10tnxaro9k8j3.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},38872,a=>{"use strict";let b={src:a.i(26758).default,width:48,height:48};a.s(["default",0,b])},49420,a=>{a.v("/_next/static/media/icon0.14we..jnd~v9t.svg"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},76717,a=>{"use strict";let b={src:a.i(49420).default,width:1272,height:1272};a.s(["default",0,b])},76789,a=>{a.v("/_next/static/media/apple-icon.01v_vf9.oz3x9.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},59310,a=>{"use strict";let b={src:a.i(76789).default,width:180,height:180};a.s(["default",0,b])},18202,a=>{a.v("/_next/static/media/icon1.0n~imj.jnvoz8.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},27963,a=>{"use strict";let b={src:a.i(18202).default,width:96,height:96};a.s(["default",0,b])},45740,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function(){return(0,b.jsx)("div",{className:"relative py-4 font-sans",children:(0,b.jsxs)("div",{className:"relative z-10 mx-auto max-w-180 animate-pulse",children:[(0,b.jsxs)("div",{className:"mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-gray-100 bg-white/70 px-6 py-4 shadow-[0_8px_16px_rgba(160,60,60,0.06)] backdrop-blur-xl",children:[(0,b.jsx)("div",{className:"h-4 w-48 rounded-lg bg-rose-100/70"}),(0,b.jsx)("div",{className:"h-10 w-36 rounded-[14px] bg-slate-200/70"})]}),(0,b.jsxs)("div",{className:"rounded-3xl border border-white/85 bg-white/65 px-10 py-10 shadow-[0_24px_48px_rgba(160,60,60,0.10)] backdrop-blur-2xl",children:[(0,b.jsxs)("div",{className:"mb-8 border-b border-[rgba(240,180,180,0.4)] pb-6",children:[(0,b.jsx)("div",{className:"mb-3 h-8 w-72 rounded-lg bg-rose-100/70"}),(0,b.jsx)("div",{className:"h-4 w-60 rounded-full bg-rose-100/50"})]}),(0,b.jsxs)("div",{className:"mb-8",children:[(0,b.jsx)("div",{className:"mb-5 h-3.5 w-32 rounded-full bg-rose-100/70"}),(0,b.jsx)("div",{className:"grid grid-cols-3 gap-x-6 gap-y-5 max-sm:grid-cols-1",children:[1,2,3,4].map(a=>(0,b.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,b.jsx)("div",{className:"h-3 w-24 rounded-full bg-rose-100/50"}),(0,b.jsx)("div",{className:"h-4 w-36 rounded-lg bg-rose-100/60"})]},a))})]}),(0,b.jsxs)("div",{className:"mb-8 border-t border-[rgba(240,180,180,0.4)] pt-8",children:[(0,b.jsx)("div",{className:"mb-5 h-3.5 w-28 rounded-full bg-rose-100/70"}),(0,b.jsx)("div",{className:"mb-6 grid grid-cols-2 gap-x-6 gap-y-5 max-sm:grid-cols-1",children:[1,2].map(a=>(0,b.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,b.jsx)("div",{className:"h-3 w-28 rounded-full bg-rose-100/50"}),(0,b.jsx)("div",{className:"h-4 w-40 rounded-lg bg-rose-100/60"})]},a))}),(0,b.jsxs)("div",{className:"mb-6",children:[(0,b.jsx)("div",{className:"mb-3 h-3 w-32 rounded-full bg-rose-100/50"}),(0,b.jsx)("div",{className:"flex flex-wrap gap-2",children:[1,2,3,4].map(a=>(0,b.jsx)("div",{className:"h-8 w-24 rounded-md border border-slate-200 bg-slate-100/60"},a))})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"mb-3 h-3 w-44 rounded-full bg-rose-100/50"}),(0,b.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,b.jsx)("div",{className:"h-3 w-full rounded-full bg-rose-100/40"}),(0,b.jsx)("div",{className:"h-3 w-5/6 rounded-full bg-rose-100/40"})]})]})]}),(0,b.jsxs)("div",{className:"mb-8 border-t border-[rgba(240,180,180,0.4)] pt-8",children:[(0,b.jsx)("div",{className:"mb-5 h-3.5 w-32 rounded-full bg-rose-100/70"}),(0,b.jsxs)("div",{className:"grid grid-cols-2 gap-6 max-sm:grid-cols-1",children:[(0,b.jsxs)("div",{className:"rounded-2xl border border-[rgba(240,180,180,0.4)] bg-white/60 px-5 py-5",children:[(0,b.jsx)("div",{className:"mb-3 h-3 w-24 rounded-full bg-rose-100/50"}),(0,b.jsx)("div",{className:"mb-4 h-4 w-36 rounded-lg bg-rose-100/70"}),(0,b.jsx)("div",{className:"mb-4 h-6 w-20 rounded-full bg-rose-100/60"}),(0,b.jsxs)("div",{className:"mt-3 flex flex-col gap-1.5",children:[(0,b.jsx)("div",{className:"h-2.5 w-full rounded-full bg-rose-100/40"}),(0,b.jsx)("div",{className:"h-2.5 w-4/5 rounded-full bg-rose-100/40"})]})]}),(0,b.jsxs)("div",{className:"rounded-2xl border border-[rgba(240,180,180,0.4)] bg-white/60 px-5 py-5",children:[(0,b.jsx)("div",{className:"mb-3 h-3 w-20 rounded-full bg-rose-100/50"}),(0,b.jsx)("div",{className:"mb-4 h-4 w-40 rounded-lg bg-rose-100/70"}),(0,b.jsx)("div",{className:"mb-4 h-6 w-20 rounded-full bg-rose-100/60"}),(0,b.jsxs)("div",{className:"mt-3 flex flex-col gap-1.5",children:[(0,b.jsx)("div",{className:"h-2.5 w-full rounded-full bg-rose-100/40"}),(0,b.jsx)("div",{className:"h-2.5 w-3/5 rounded-full bg-rose-100/40"})]})]})]})]})]})]})})}])},14598,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/ITApprovers/ITReqPdfModal.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/ITApprovers/ITReqPdfModal.tsx <module evaluation>","default")},84850,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/ITApprovers/ITReqPdfModal.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/ITApprovers/ITReqPdfModal.tsx","default")},49349,a=>{"use strict";a.i(14598);var b=a.i(84850);a.n(b)},85942,a=>a.a(async(b,c)=>{try{var d=a.i(7997),e=a.i(69083),f=a.i(717),g=a.i(66879),h=a.i(44908),i=a.i(5675),j=a.i(46706),k=a.i(51016),l=a.i(45740),m=a.i(49349),n=b([e,g]);[e,g]=n.then?(await n)():n;let o=async({params:a})=>{let{uuid:b}=await a;if(!b)return(0,d.jsx)(h.default,{});let c=await (0,g.query)(e.ITDataQuery,[b]);if(0===c.length)return(0,d.jsx)(h.default,{});let n=c[0];return(0,d.jsx)(k.UserProvider,{user:{username:"Guest Account",email:"noreply@hotpoint.co.ke",roles:["guest"]},children:(0,d.jsx)(i.default,{children:(0,d.jsx)(j.default,{children:(0,d.jsx)(f.Suspense,{fallback:(0,d.jsx)(l.default,{}),children:(0,d.jsx)(m.default,{pdfData:n})})})})})};a.s(["default",0,o,"metadata",0,{title:"IT Requisition Pdf",description:"Download the IT requisition pdf"}]),c()}catch(a){c(a)}},!1),21564,a=>{a.n(a.i(85942))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0f_.d95._.js.map