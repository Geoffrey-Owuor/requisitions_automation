module.exports=[99450,a=>{a.v("/_next/static/media/hotpoint_icon.03v1kd-iqopka.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},54442,a=>{a.v("/_next/static/media/form_image.016.01-z~7ilt.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},91962,a=>{a.v("/_next/static/media/hotpoint_logo.14-vmxudg2qno.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,a=>{a.v("/_next/static/media/hotpoint_black_logo.0m41_m1z8uhzw.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},11985,a=>{a.v("/_next/static/media/it_form_image.0lz1c.hirvfk_.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},23862,a=>a.a(async(b,c)=>{try{let b=await a.y("pg-587764f78a6c7a9c");a.n(b),c()}catch(a){c(a)}},!0),66879,a=>a.a(async(b,c)=>{try{let g;var d=a.i(23862),e=b([d]);[d]=e.then?(await e)():e;let h={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function f(a,b){let c=await g.connect();try{return(await c.query(a,b)).rows}finally{c.release()}}g=new d.Pool(h),a.s(["pool",0,g,"query",0,f]),c()}catch(a){c(a)}},!1),37936,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"registerServerReference",{enumerable:!0,get:function(){return d.registerServerReference}});let d=a.r(11857)},13095,(a,b,c)=>{"use strict";function d(a){for(let b=0;b<a.length;b++){let c=a[b];if("function"!=typeof c)throw Object.defineProperty(Error(`A "use server" file can only export async functions, found ${typeof c}.
Read more: https://nextjs.org/docs/messages/invalid-use-server-value`),"__NEXT_ERROR_CODE",{value:"E352",enumerable:!1,configurable:!0})}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"ensureServerEntryExports",{enumerable:!0,get:function(){return d}})},54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))},88947,(a,b,c)=>{b.exports=a.x("stream",()=>require("stream"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},66680,(a,b,c)=>{b.exports=a.x("node:crypto",()=>require("node:crypto"))},21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},1515,a=>{"use strict";let b={src:a.i(99450).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAMBAAQyCQI7dBQFi4YXBqF9FQaVQgsDS4MWBpxyFAaGAEILA061IAnfyyQK/MokCvm8IQnmZBIFdsgjCvarHgnTAJsbCLzKJAr7fRYGlmMRBXJbEARpTA4DWccjCvarHgnSALEfCdjDIgryVQ8EY6weCNKkHQjHVA4EY8cjCvarHwnSALIfCdrCIgnvTQ0EWJ4cCMGWGge2Ug4EYccjCverHwnSALMgCdvBIgruSQ0EU3EUBYZzFAaJkRoHscslC/2aGwi8ALMfCdzBIgruYhEFc8UjCvPNJAr+zCUK/bUgCeBEDARRAGIQBXRqEgV+NgkDPWwTBYJwEwWJZxIFfDEIAjoEAQAETr5TfppXlUsAAAAASUVORK5CYII="},c={src:a.i(54442).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYFha9ND51fmHZ9NTcntjUCRmFk4uq2xNzAI3jCztmkPycAAAAAElFTkSuQmCC"},d={src:a.i(91962).default,width:800,height:360,blurWidth:8,blurHeight:4,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAZElEQVR42k3MMQqFQBAD0GTmy+5fFe08gaUHsBPsLUUEa1vR+4MRLBx4DCQQAKglSTQgI6CHXIL8YeaHuV/ufg6p3NsQd2Xnk9FsAcmOtN5lSMXa/LJJxSazuhHfC+QzG6V6pRv3AAds+3z7uwAAAABJRU5ErkJggg=="},e={src:a.i(41535).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAk0lEQVR42j3QLwvCQBiA8Tf4qRQ/gSCIRaOYrComMRgEMWuy+BEsJovJrmVsgy0tbrDBxtgf9hy8W/jBcfdwd7wiIj0McMEDV4xwxwkyhocSOQLskOJvgjcK3LDGCnMNfiawEGOpG19dd4GNCDN88MICWRs4CDHVT53xRKXPi6vBBglqPfQxMcEWBwxx1Bv26JsRNFZmKZZ3JF37AAAAAElFTkSuQmCC"},f={src:a.i(11985).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYUlyyML9odl7RxLiU/qTM9uiUlsiU3rxyAJDeCy/80jrPAAAAAElFTkSuQmCC"};a.s(["assets",0,{hotpoint_logo:b,form_image:c,hotpoint_background:d,hotpoint_black_logo:e,it_form_image:f},"dateFormatter",0,function(a){return a?new Date(a).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"—"}],1515)},90849,a=>{"use strict";var b=a.i(1515);function c(a,b){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 40%; border-bottom: 1px solid #f7f0f0;">${a}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${b||"—"}</td>
    </tr>`}function d(a,b,c,d){let e=(b||"").toLowerCase(),f="#854d0e",g="#fef9c3",h="1px solid #854d0e";return(e.includes("approved")||e.includes("accepted"))&&(f="#166534",g="#dcfce7",h="1px solid #166534"),(e.includes("declined")||e.includes("rejected"))&&(f="#991b1b",g="#fee2e2",h="1px solid #991b1b"),`
    <div style="border-radius: 12px; border: 1px solid #f0e6e6; padding: 14px 16px; background-color: #ffffff;">
      <p style="margin: 0 0 2px; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase; letter-spacing: 1px;">${a}</p>
      <p style="margin: 0 0 8px; font-size: 13px; color: #1a0f0f; font-weight: 600;">${c||"Awaiting Assignment"}</p>
      <span style="padding: 3px 9px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${f}; background-color: ${g}; border: ${h}; text-transform: uppercase; display: inline-block;">${b||"Pending"}</span>
      <p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 6px 10px; border-radius: 8px; border: 1px dashed #eee;">"${d||"N/A"}"</p>
    </div>
  `}a.s(["ITRequisitionTemplate",0,function({requestId:a,message:e,title:f,role:g,emailData:h,reviewLink:i}){let j=(0,b.dateFormatter)(h.datesubmitted),k=(0,b.dateFormatter)(h.requisitiondate),l=(0,b.dateFormatter)(h.datejoining);return`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">

        <!-- Header: solid background avoids Outlook gradient rendering issues -->
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
          <table width="100%">
            <tr>
              <td style="vertical-align: middle;">
                <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.85;">IT Department</p>
                <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${f}</h2>
              </td>
              <td style="text-align: right; vertical-align: middle;">
                <div style="display: inline-block; background-color: #7f1d1d; border-radius: 12px; padding: 8px 14px;">
                  <p style="margin: 0; font-size: 11px; font-weight: 700; color: #f2d7d5; letter-spacing: 1px;">IT REQ</p>
                </div>
              </td>
            </tr>
          </table>
        </div>

        <div style="padding: 30px 24px;">

          <!-- Message box: explicit white avoids Outlook dark-mode unpredictability -->
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #dbeafe;">
            <p style="margin: 0; font-size: 15px; color: #1e293b; line-height: 1.6;">${e}</p>
          </div>

          <!-- Submission meta strip -->
          <div style="background-color: #fdf2f2; border-radius: 12px; padding: 12px 16px; margin-bottom: 24px; border: 1px solid #f2d7d5;">
            <table width="100%">
              <tr>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Submitted by</td>
                <td style="font-size: 11px; color: #a31d1d; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; text-align: right;">Date Submitted</td>
              </tr>
              <tr>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px;">${h.submittername||"—"}</td>
                <td style="font-size: 14px; color: #3b0a0a; font-weight: 600; padding-top: 2px; text-align: right;">${j}</td>
              </tr>
            </table>
          </div>

          <!-- Employee Information -->
          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Employee Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${c("Employee Name",h.employeename)}
              ${c("Staff Number",h.employeestaffnumber)}
              ${c("Department",h.employeedepartment)}
              ${c("Date Joining",l)}
              ${c("Requisition Date",k)}
            </table>
          </div>

          <!-- Equipment Details: dark solid box (same gradient-avoidance fix as Travel) -->
          <div style="background-color: #0f172a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(30,58,138,0.3);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #f87171; text-transform: uppercase; letter-spacing: 2px;">Equipment Details</p>
            <table width="100%">
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8;">Request Type</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${h.replacementnew||"—"}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #94a3b8; vertical-align: top;">Requirements</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">${h.requirements||"—"}</td>
              </tr>
              ${h.otherrequirements?`<tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 12px;">
                  <p style="margin: 0 0 4px; font-size: 10px; font-weight: 700; color: #f87171; text-transform: uppercase; letter-spacing: 1px;">Additional Requirements</p>
                  <p style="margin: 0; font-size: 12px; color: #cbd5e1; line-height: 1.5;">${h.otherrequirements}</p>
                </td>
              </tr>`:""}
            </table>
          </div>

          <!-- Approval Workflow -->
          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>

          <!-- Two-column grid via table for Outlook compatibility -->
          <table width="100%" style="border-collapse: separate; border-spacing: 0 0; margin-bottom: 24px;">
            <tr>
              <td width="49%" style="vertical-align: top; padding-right: 8px;">
                ${d("Head of Department",h.hodapprovalstatus,h.hodapprover,h.hodcomments)}
              </td>
              <td width="2%"></td>
              <td width="49%" style="vertical-align: top;">
                ${d("IT Department",h.itapprovalstatus,h.itapprover,h.itcomments)}
              </td>
            </tr>
          </table>

          <!-- CTA Button -->
          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==g?"display: inline-block;":"display: none;"}">
              <a href="https://192.168.0.155/itapproval/${a}${i??""}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
          </div>

        </div>

        <!-- Footer: explicit white avoids near-white Outlook dark-mode issues -->
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #64748b; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | IT Requisition</p>
        </div>

      </div>
    </div>
  `}])},69083,a=>a.a(async(b,c)=>{try{var d=a.i(717),e=a.i(66879),f=a.i(35723),g=a.i(90849),h=b([e]);[e]=h.then?(await h)():h;let j=`
  SELECT
  request_created_at AS datesubmitted,
  submitter_name AS submittername,
  employee_name AS employeename,
  employee_staff_number AS employeestaffnumber,
  employee_department AS employeedepartment,
  replacement_new AS replacementnew,
  requirements,
  other_requirements AS otherrequirements,
  requisition_date AS requisitiondate,
  date_joining AS datejoining,
  hod_approver_name AS hodapprover,
  hod_approver_status AS hodapprovalstatus,
  hod_approver_comments AS hodcomments,
  it_approver_name AS itapprover,
  it_approver_status AS itapprovalstatus,
  it_approver_comments AS itcomments
  FROM it_requisitions WHERE request_id = $1
`,k=(0,d.cache)(async a=>(await (0,e.query)(j,[a]))[0]);async function i({to:a,requestId:b,message:c,title:d,role:e,reviewLink:h}){let j=await k(b),l=(0,g.ITRequisitionTemplate)({requestId:b,title:d,message:c,role:e,emailData:j,reviewLink:h});await (0,f.sendEmail)({from:process.env.IT_EMAIL_SENDER,to:a,subject:d,html:l})}a.s(["ITDataQuery",0,j,"ITEmailSender",0,i]),c()}catch(a){c(a)}},!1),28803,a=>a.a(async(b,c)=>{try{var d=a.i(69083),e=b([d]);async function f({uuid:a,userEmail:b,hodEmail:c,status:e,approverEmail:g,approverName:h}){"rejected"===e&&((0,d.ITEmailSender)({to:g,requestId:a,message:"You have rejected this IT requisition",title:"Final Update: IT Requisition Rejected",role:"user"}),c===b||(0,d.ITEmailSender)({to:c,requestId:a,message:`This IT Requisition has been rejected by ${h}`,title:"Final Update: IT Requisition Rejected",role:"user"}),(0,d.ITEmailSender)({to:b,requestId:a,message:`Your IT Requisition has been rejected by ${h}`,title:"Final Update: IT Requisition Rejected",role:"user"})),"accepted"===e&&((0,d.ITEmailSender)({to:g,requestId:a,message:"You have accepted this IT requisition",title:"Final Update: IT Requisition Accepted",role:"user"}),c===b||(0,d.ITEmailSender)({to:c,requestId:a,message:`This IT Requisition has been accepted by ${h}`,title:"Final Update: IT Requisition Accepted",role:"user"}),(0,d.ITEmailSender)({to:b,requestId:a,message:`Your IT Requisition has been accepted by ${h}`,title:"Final Update: IT Requisition Accepted",role:"user"}))}[d]=e.then?(await e)():e,a.s(["itApprovalStage",0,f]),c()}catch(a){c(a)}},!1),20230,a=>a.a(async(b,c)=>{try{var d=a.i(69083),e=a.i(9283),f=b([d,e]);async function g({uuid:a,userEmail:b,status:c,approverEmail:f,approverName:h}){let i=await (0,e.loadITArray)();"declined"===c&&((0,d.ITEmailSender)({to:f,requestId:a,message:"You have declined this travel requisition",title:"Final Update: IT Requisition Declined",role:"user"}),(0,d.ITEmailSender)({to:b,requestId:a,message:`Your travel requisition has been declined by ${h}`,title:"Final Update: IT Requisition Declined",role:"user"})),"approved"===c&&(i.forEach(b=>{(0,d.ITEmailSender)({to:b.email,requestId:a,message:"A new IT requisition has been submitted and requires your review",title:"Action Required: New IT Requisition",role:"IT",reviewLink:`?token=${b.uuid}&stage=it`})}),(0,d.ITEmailSender)({to:f,requestId:a,message:"You have approved this IT requisition, it has been forwarded to IT for review",title:"Update: IT Requisition Approved",role:"user"}),(0,d.ITEmailSender)({to:b,requestId:a,message:`Your IT requisition has been approved by ${h} and forwarded to IT for review`,title:"Update: IT Requisition Approved",role:"user"}))}[d,e]=f.then?(await f)():f,a.s(["hodApprovalStage",0,g]),c()}catch(a){c(a)}},!1),31682,a=>a.a(async(b,c)=>{try{var d=a.i(37936),e=a.i(66879),f=a.i(69083),g=a.i(28803),h=a.i(20230),i=a.i(13095),j=b([e,f,g,h]);async function k(a){let b,c=`
  UPDATE it_requisitions
  SET ${a.stage}_approval_date = CURRENT_TIMESTAMP,
  ${a.stage}_approver_status = $1,
  ${a.stage}_approver_name = $2,
  ${a.stage}_approver_email = $3,
  ${a.stage}_approver_comments = $4
  WHERE request_id = $5
  `,d=[a.status,a.approverName,a.approverEmail,a.comments,a.uuid];try{b=await e.pool.connect(),await b.query("BEGIN");let{rows:i}=await b.query(`
      SELECT ${a.stage}_approver_status AS approval_status,
      ${a.stage}_approver_name AS approver,
      submitter_email, hod_approver_email
      FROM it_requisitions WHERE request_id = $1 FOR UPDATE
      `,[a.uuid]);if(0===i.length)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:"The selected requisition for update could not be found, please contact your admin for support"};let{rows:j}=await b.query(`SELECT id FROM ${a.stage}_array WHERE ${a.stage}_email = $1 FOR UPDATE`,[a.approverEmail]);if(0===j.length)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:"Could not verify the current approver, please contact your admin for support"};let k=i[0].approval_status,l=i[0].approver,m=i[0].submitter_email,n=i[0].hod_approver_email;if("pending"!==k)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:`This requisition has already been acted upon by ${l}, no further action is required`};switch(await b.query(c,d),await b.query("COMMIT"),a.stage){case"hod":(0,h.hodApprovalStage)({uuid:a.uuid,userEmail:m,status:a.status,approverEmail:a.approverEmail,approverName:a.approverName});break;case"it":(0,g.itApprovalStage)({uuid:a.uuid,userEmail:m,hodEmail:n,status:a.status,approverEmail:a.approverEmail,approverName:a.approverName});break;default:(0,f.ITEmailSender)({to:"geoffrey@hotpoint.co.ke",requestId:a.uuid,message:"A wrong stage was passed in the travel requisition approval workflow for this requistion",title:"Wrong stage passed to travel requisition approval workflow",role:"user"})}return{alertType:"success",alertMessage:"This requisition status has been updated successfully, you may now safely close this window"}}catch(a){return await b?.query("ROLLBACK"),console.error("Error while trying to update the status of this requisition",a),{alertType:"error",alertMessage:"An error occured while trying to update the status of this requisition"}}finally{b&&b.release()}}[e,f,g,h]=j.then?(await j)():j,(0,i.ensureServerEntryExports)([k]),(0,d.registerServerReference)(k,"40f74ed81554ccd33da340daf4c99b8512aee8c873",null),a.s(["UpdateITRequisitionStatus",0,k]),c()}catch(a){c(a)}},!1),94353,a=>a.a(async(b,c)=>{try{var d=a.i(31682),e=b([d]);[d]=e.then?(await e)():e,a.s([]),c()}catch(a){c(a)}},!1),52791,a=>a.a(async(b,c)=>{try{var d=a.i(94353),e=a.i(31682),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s(["40f74ed81554ccd33da340daf4c99b8512aee8c873",()=>e.UpdateITRequisitionStatus]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__0w64fqj._.js.map