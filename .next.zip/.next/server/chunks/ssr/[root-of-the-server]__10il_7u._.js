module.exports=[99450,a=>{a.v("/_next/static/media/hotpoint_icon.03v1kd-iqopka.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},54442,a=>{a.v("/_next/static/media/form_image.016.01-z~7ilt.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},91962,a=>{a.v("/_next/static/media/hotpoint_logo.14-vmxudg2qno.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,a=>{a.v("/_next/static/media/hotpoint_black_logo.0m41_m1z8uhzw.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},11985,a=>{a.v("/_next/static/media/it_form_image.0lz1c.hirvfk_.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},23862,a=>a.a(async(b,c)=>{try{let b=await a.y("pg-587764f78a6c7a9c");a.n(b),c()}catch(a){c(a)}},!0),66879,a=>a.a(async(b,c)=>{try{let g;var d=a.i(23862),e=b([d]);[d]=e.then?(await e)():e;let h={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function f(a,b){let c=await g.connect();try{return(await c.query(a,b)).rows}finally{c.release()}}g=new d.Pool(h),a.s(["pool",0,g,"query",0,f]),c()}catch(a){c(a)}},!1),37936,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"registerServerReference",{enumerable:!0,get:function(){return d.registerServerReference}});let d=a.r(11857)},13095,(a,b,c)=>{"use strict";function d(a){for(let b=0;b<a.length;b++){let c=a[b];if("function"!=typeof c)throw Object.defineProperty(Error(`A "use server" file can only export async functions, found ${typeof c}.
Read more: https://nextjs.org/docs/messages/invalid-use-server-value`),"__NEXT_ERROR_CODE",{value:"E352",enumerable:!1,configurable:!0})}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"ensureServerEntryExports",{enumerable:!0,get:function(){return d}})},54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))},88947,(a,b,c)=>{b.exports=a.x("stream",()=>require("stream"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},66680,(a,b,c)=>{b.exports=a.x("node:crypto",()=>require("node:crypto"))},21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},1515,a=>{"use strict";let b={src:a.i(99450).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAMBAAQyCQI7dBQFi4YXBqF9FQaVQgsDS4MWBpxyFAaGAEILA061IAnfyyQK/MokCvm8IQnmZBIFdsgjCvarHgnTAJsbCLzKJAr7fRYGlmMRBXJbEARpTA4DWccjCvarHgnSALEfCdjDIgryVQ8EY6weCNKkHQjHVA4EY8cjCvarHwnSALIfCdrCIgnvTQ0EWJ4cCMGWGge2Ug4EYccjCverHwnSALMgCdvBIgruSQ0EU3EUBYZzFAaJkRoHscslC/2aGwi8ALMfCdzBIgruYhEFc8UjCvPNJAr+zCUK/bUgCeBEDARRAGIQBXRqEgV+NgkDPWwTBYJwEwWJZxIFfDEIAjoEAQAETr5TfppXlUsAAAAASUVORK5CYII="},c={src:a.i(54442).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYFha9ND51fmHZ9NTcntjUCRmFk4uq2xNzAI3jCztmkPycAAAAAElFTkSuQmCC"},d={src:a.i(91962).default,width:800,height:360,blurWidth:8,blurHeight:4,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAZElEQVR42k3MMQqFQBAD0GTmy+5fFe08gaUHsBPsLUUEa1vR+4MRLBx4DCQQAKglSTQgI6CHXIL8YeaHuV/ufg6p3NsQd2Xnk9FsAcmOtN5lSMXa/LJJxSazuhHfC+QzG6V6pRv3AAds+3z7uwAAAABJRU5ErkJggg=="},e={src:a.i(41535).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAk0lEQVR42j3QLwvCQBiA8Tf4qRQ/gSCIRaOYrComMRgEMWuy+BEsJovJrmVsgy0tbrDBxtgf9hy8W/jBcfdwd7wiIj0McMEDV4xwxwkyhocSOQLskOJvgjcK3LDGCnMNfiawEGOpG19dd4GNCDN88MICWRs4CDHVT53xRKXPi6vBBglqPfQxMcEWBwxx1Bv26JsRNFZmKZZ3JF37AAAAAElFTkSuQmCC"},f={src:a.i(11985).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYUlyyML9odl7RxLiU/qTM9uiUlsiU3rxyAJDeCy/80jrPAAAAAElFTkSuQmCC"};a.s(["assets",0,{hotpoint_logo:b,form_image:c,hotpoint_background:d,hotpoint_black_logo:e,it_form_image:f},"dateFormatter",0,function(a){return a?new Date(a).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"—"}],1515)},36324,a=>{"use strict";var b=a.i(1515);let c="https://192.168.0.155";function d(a,b){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 35%; border-bottom: 1px solid #f7f0f0;">${a}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${b||"—"}</td>
    </tr>`}function e(a,b,c,d,f,g=!1){let h=(b||"").toLowerCase(),i="#856404",j="#fff3cd",k="1px solid #856404";return h.includes("approved")&&(i="#155724",j="#d4edda",k="1px solid #155724"),h.includes("declined")&&(i="#721c24",j="#f8d7da",k="1px solid #721c24"),`
    <div style="padding: 16px; border-bottom: ${g?"none":"1px solid #f0e6e6"}; background-color: #ffffff;">
      <table width="100%">
        <tr>
          <td>
            <p style="margin: 0; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase;">${a}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${c||"Awaiting Assignment"}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${d||"Awaiting Assignment"}</p>
          </td>
          <td style="text-align: right;">
           
            <span style="padding: 4px 10px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${i}; background-color: ${j}; border: ${k}; text-transform: uppercase;">${b||"Pending"}</span>
          </td>
        </tr>
      </table>
      ${f?`<p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 8px; border-radius: 8px; border: 1px dashed #eee;">"${f}"</p>`:""}
    </div>
  `}a.s(["TravelRequisitionTemplate",0,function({requestId:a,message:f,title:g,role:h,emailData:i,reviewLink:j,showPdfDownload:k}){let l=(0,b.dateFormatter)(i.departuredate),m=(0,b.dateFormatter)(i.returndate),n=[],o=0;return"Engineering & HVAC"===i.department&&i.engineeringjobs&&(n=i.engineeringjobs.split("\n").filter(a=>""!==a.trim()).map(a=>{let[b,c]=a.split(" - "),d=Number(c)||0;return o+=d,{title:b?.trim()||"Unknown Job",amount:d}})),`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">
        
       
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
           <table width="100%">
             <tr>
               <td style="vertical-align: middle;">
                 <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.8;">New Requisition</p>
                 <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${g}</h2>
               </td>
             </tr>
           </table>
        </div>

        <div style="padding: 30px 24px;">
          
          
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #f9e8e8;">
            <p style="margin: 0; font-size: 15px; color: #4a3a3a; line-height: 1.6;">${f}</p>
          </div>

          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Primary Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${d("Employee",i.employeename)}
              ${d("Email",i.emailaddress)}
              ${d("Department",i.department)}
              ${d("Designation",i.designation)}
              ${d("Destination",i.destination)}
              ${d("Travel Category",i.travelcategory)}
              ${d("Travel Dates",`${l} - ${m}`)}
              ${d("Transport Mode",i.modeoftransport)}
              ${d("Business Justification",i.businessjustification)}
              ${d("Cost Centre",i.costcentre)}
              ${d("Approval Tier",i.approvaltier)}
              ${d("Within Budget",i.withinbudget)}
            </table>
          </div>

          ${function(a,b){if(!a||0===a.length)return"";let c=a.map(a=>`
      <tr>
        <td style="padding-bottom: 12px; font-size: 12px; color: #7c5a5a;">${a.title}</td>
        <td style="padding-bottom: 12px; font-size: 12px; color: #1e1b1b; text-align: right; font-weight: 600;">KES ${Number(a.amount).toLocaleString()}</td>
      </tr>
    `).join("");return`
    <div style="background-color: #ffffff; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
      <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Engineering Job Allocations</p>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        ${c}
        <tr>
          <td colspan="2" style="border-top: 1px solid rgba(163,29,29,0.2); padding-top: 12px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td style="font-size: 14px; font-weight: 700; color: #a31d1d;">Allocations Subtotal</td>
                <td style="font-size: 16px; font-weight: 700; color: #1e1b1b; text-align: right;">KES ${Number(b).toLocaleString()}</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  `}(n,o)}

          <div style="background-color: #2c1a1a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Budget Summary</p>
            <table width="100%">
              <tr>
                
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Transport Cost</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.twowaytransportcost}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Other Costs</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.othercosts}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Per Diem Entitlement</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.perdiempolicy}</td>
              </tr>
              <tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 12px;">
                  <table width="100%">
                    <tr>
                      <td style="font-size: 14px; font-weight: 700; color: #f2d7d5;">Total Cost</td>
                      <td style="font-size: 20px; font-weight: 700; color: #ffffff; text-align: right;">KES ${i.estimatedcost}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>

          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>
          <div style="border-radius: 16px; border: 1px solid #f0e6e6; overflow: hidden;">
             ${e("Head of Department",i.hodapprovalstatus,i.hodapprover,i.hodemail,i.hodcomments)}
             ${"Tier 2"===i.approvaltier||"Tier 3"===i.approvaltier?e("Human Resources",i.hrapprovalstatus,i.hrapprover,i.hremail,i.hrcomments):""}
             ${"Tier 3"===i.approvaltier?e("Executive Director",i.directorapprovalstatus,i.directorapprover,i.directoremail,i.directorcomments,!0):""}
          </div>

          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==h?"display: inline-block;":"display: none;"}">
              <a href="${c}/travelapproval/${a}${j}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
            <div style="${k?"display: inline-block; margin-top: 10px;":"display: none;"} width: 100%;">
              <a href="${c}/travelapproval/${a}/pdfdownload" style="color: #a31d1d; font-size: 12px; font-weight: 600; text-decoration: underline; display: inline-block; margin-top: 12px;">Download PDF Summary</a>
            </div>
          </div>

        </div>

        
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #8c7474; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | Travel Requisition</p>
        </div>
      </div>
    </div>
  `}])},74561,a=>a.a(async(b,c)=>{try{var d=a.i(717),e=a.i(66879),f=a.i(36324),g=a.i(35723),h=b([e]);[e]=h.then?(await h)():h;let j=`
     SELECT 
       submitter_email AS emailaddress, 
       employee_name AS employeename, 
       employee_department AS department, 
       employee_designation AS designation, 
       travel_destination AS destination, 
       travel_departure_date AS departuredate, 
       travel_return_date AS returndate, 
       travel_category AS travelcategory,
       travel_business_justification AS businessjustification, 
       travel_mode AS modeoftransport, 
       travel_transport_cost AS twowaytransportcost, 
       travel_other_costs AS othercosts, 
       travel_per_diem AS perdiempolicy, 
       travel_total_cost AS estimatedcost, 
       travel_cost_center AS costcentre, 
       travel_within_budget AS withinbudget,
       travel_approval_tier AS approvaltier, 
       travel_hod_approval_status AS hodapprovalstatus, 
       travel_hr_approval_status AS hrapprovalstatus,
       travel_director_approval_status AS directorapprovalstatus, 
       travel_hod_approver AS hodapprover,
       travel_hod_email AS hodemail,
       travel_hod_comments AS hodcomments,
       travel_hr_approver AS hrapprover,
       travel_hr_email AS hremail,
       travel_hr_comments AS hrcomments,
       travel_director_approver AS directorapprover,
       travel_director_email AS directoremail,
       travel_director_comments AS directorcomments,
       engineering_jobs AS engineeringjobs
       FROM travel_requisitions WHERE request_id = $1
`,k=(0,d.cache)(async a=>(await (0,e.query)(j,[a]))[0]);async function i({to:a,requestId:b,message:c,title:d,role:e,reviewLink:h,showPdfDownload:j=!1}){let l=await k(b),m=(0,f.TravelRequisitionTemplate)({requestId:b,message:c,title:d,role:e,emailData:l,reviewLink:h,showPdfDownload:j});await (0,g.sendEmail)({from:process.env.EMAIL_SENDER,to:a,subject:d,html:m})}a.s(["EmailSender",0,i,"travelDataQuery",0,j]),c()}catch(a){c(a)}},!1),61220,a=>a.a(async(b,c)=>{try{var d=a.i(74561),e=a.i(9283),f=b([d,e]);async function g({uuid:a,userEmail:b,status:c,approverEmail:f,approverName:h,approvalTier:i}){let j=await (0,e.loadHrArray)();"declined"===c&&((0,d.EmailSender)({to:f,requestId:a,message:"You have declined this travel requisition.",title:"Final Update: Travel Requisition Declined",role:"user"}),(0,d.EmailSender)({to:b,requestId:a,message:"Your travel requisition has been declined in the HOD approval stage",title:`Final Update: Travel Requisition Declined By ${h}`,role:"user"})),"approved"===c&&("Tier 1"===i?((0,d.EmailSender)({to:f,requestId:a,message:"You have approved this travel requisition",title:"Final Update: Travel Requisition Approved",role:"user",showPdfDownload:!0}),(0,d.EmailSender)({to:b,requestId:a,message:`Your travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0}),(0,d.EmailSender)({to:process.env.FIRST_FINANCE_EMAIL,requestId:a,message:`This travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0})):(j.forEach(b=>{(0,d.EmailSender)({to:b.email,requestId:a,message:"A new travel requisition has been submitted and requires your approval",title:"Action Required: New Travel Requisition",role:"HR",reviewLink:`?token=${b.uuid}&stage=hr`})}),(0,d.EmailSender)({to:f,requestId:a,message:"You have approved this travel requisition. It has been forwarded to HR for the next approval stage",title:"Update: Travel Requisition Approved",role:"user"}),(0,d.EmailSender)({to:b,requestId:a,message:`Your travel requisition has been approved by ${h} and has been forwaded to HR for the next approval stage`,title:`Update: Travel Requisition Approved By ${h}`,role:"user"})))}[d,e]=f.then?(await f)():f,a.s(["hodApprovalStage",0,g]),c()}catch(a){c(a)}},!1),35031,a=>a.a(async(b,c)=>{try{var d=a.i(9283),e=a.i(74561),f=b([d,e]);async function g({uuid:a,userEmail:b,hodEmail:c,status:f,approverEmail:h,approverName:i,approvalTier:j}){let k=await (0,d.loadDirectorArray)();"declined"===f&&((0,e.EmailSender)({to:h,requestId:a,message:"You have declined this travel requisition.",title:"Final Update: Travel Requisition Declined",role:"user"}),c===b||(0,e.EmailSender)({to:c,requestId:a,message:"This travel requisition has been declined in the HR approval stage",title:`Final Update: Travel Requisition Declined By ${i}`,role:"user"}),(0,e.EmailSender)({to:b,requestId:a,message:"Your travel requisition has been declined in the HR approval stage",title:`Final Update: Travel Requisition Declined By ${i}`,role:"user"})),"approved"===f&&("Tier 2"===j?((0,e.EmailSender)({to:h,requestId:a,message:"You have approved this travel requisition",title:"Final Update: Travel Requisition Approved",role:"user",showPdfDownload:!0}),c===b||(0,e.EmailSender)({to:c,requestId:a,message:`This travel requisition has been approved by ${i}`,title:`Final Update: Travel Requisition Approved By ${i}`,role:"user",showPdfDownload:!0}),(0,e.EmailSender)({to:b,requestId:a,message:`Your travel requisition has been approved by ${i}`,title:`Final Update: Travel Requisition Approved By ${i}`,role:"user",showPdfDownload:!0}),(0,e.EmailSender)({to:process.env.FIRST_FINANCE_EMAIL,requestId:a,message:`This travel requisition has been approved by ${i}`,title:`Final Update: Travel Requisition Approved By ${i}`,role:"user",showPdfDownload:!0})):(k.forEach(b=>{(0,e.EmailSender)({to:b.email,requestId:a,message:"A new travel requisition has been submitted and requires your approval",title:"Action Required: New Travel Requisition",role:"Director",reviewLink:`?token=${b.uuid}&stage=director`})}),(0,e.EmailSender)({to:h,requestId:a,message:"You have approved this travel requisition. It has been forwarded to Director Approval for the next approval stage",title:"Update: Travel Requisition Approved",role:"user"}),c===b||(0,e.EmailSender)({to:c,requestId:a,message:`This travel requisition has been approved by ${i} and has been forwaded to Director Approval for the next approval stage`,title:`Update: Travel Requisition Approved By ${i}`,role:"user"}),(0,e.EmailSender)({to:b,requestId:a,message:`Your travel requisition has been approved by ${i} and has been forwaded to Director Approval for the next approval stage`,title:`Update: Travel Requisition Approved By ${i}`,role:"user"})))}[d,e]=f.then?(await f)():f,a.s(["hrApprovalStage",0,g]),c()}catch(a){c(a)}},!1),17055,a=>a.a(async(b,c)=>{try{var d=a.i(74561),e=b([d]);[d]=e.then?(await e)():e,a.s(["directorApprovalStage",0,function({uuid:a,userEmail:b,hodEmail:c,hrEmail:e,status:f,approverEmail:g,approverName:h}){"declined"===f&&((0,d.EmailSender)({to:g,requestId:a,message:"You have declined this travel requisition.",title:"Final Update: Travel Requisition Declined",role:"user"}),c===b?(0,d.EmailSender)({to:e,requestId:a,message:"This travel requisition has been declined in the Director approval stage",title:`Final Update: Travel Requisition Declined By ${h}`,role:"user"}):(0,d.EmailSender)({to:[c,e],requestId:a,message:"This travel requisition has been declined in the Director approval stage",title:`Final Update: Travel Requisition Declined By ${h}`,role:"user"}),(0,d.EmailSender)({to:b,requestId:a,message:"Your travel requisition has been declined in the Director approval stage",title:`Final Update: Travel Requisition Declined By ${h}`,role:"user"})),"approved"===f&&((0,d.EmailSender)({to:g,requestId:a,message:"You have approved this travel requisition",title:"Final Update: Travel Requisition Approved",role:"user",showPdfDownload:!0}),c===b?(0,d.EmailSender)({to:e,requestId:a,message:`This travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0}):(0,d.EmailSender)({to:[e,c],requestId:a,message:`This travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0}),(0,d.EmailSender)({to:b,requestId:a,message:`Your travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0}),(0,d.EmailSender)({to:process.env.FIRST_FINANCE_EMAIL,requestId:a,message:`This travel requisition has been approved by ${h}`,title:`Final Update: Travel Requisition Approved By ${h}`,role:"user",showPdfDownload:!0}))}]),c()}catch(a){c(a)}},!1),67141,a=>a.a(async(b,c)=>{try{var d=a.i(37936),e=a.i(66879),f=a.i(61220),g=a.i(35031),h=a.i(17055),i=a.i(74561),j=a.i(13095),k=b([e,f,g,h,i]);async function l(a){let b,c=`
    UPDATE travel_requisitions
    SET travel_${a.stage}_approval_date = CURRENT_TIMESTAMP,
    travel_${a.stage}_approval_status = $1,
    travel_${a.stage}_approver = $2,
    travel_${a.stage}_email = $3,
    travel_${a.stage}_comments = $4
    WHERE request_id = $5
    `,d=[a.status,a.approverName,a.approverEmail,a.comments,a.uuid];try{b=await e.pool.connect(),await b.query("BEGIN");let{rows:j}=await b.query(`SELECT travel_${a.stage}_approval_status AS approval_status,
       travel_${a.stage}_approver AS approver,
       travel_approval_tier, submitter_email, travel_hod_email, travel_hr_email
        FROM travel_requisitions WHERE request_id = $1 FOR UPDATE`,[a.uuid]);if(0===j.length)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:"The selected requisition for update could not be found, please contact your admin for support"};let{rows:k}=await b.query(`SELECT id FROM ${a.stage}_array WHERE ${a.stage}_email = $1 FOR UPDATE`,[a.approverEmail]);if(0===k.length)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:"Could not verify the current approver, please contact your admin for support"};let l=j[0].approval_status,m=j[0].approver,n=j[0].submitter_email,o=j[0].travel_hod_email,p=j[0].travel_hr_email,q=j[0].travel_approval_tier;if("pending"!==l&&"N/A"!==l)return await b.query("ROLLBACK"),{alertType:"error",alertMessage:`This requisition has already been acted upon by ${m}, no further action is required`};switch(await b.query(c,d),await b.query("COMMIT"),a.stage){case"hod":(0,f.hodApprovalStage)({uuid:a.uuid,userEmail:n,status:a.status,approverEmail:a.approverEmail,approverName:a.approverName,approvalTier:q});break;case"hr":(0,g.hrApprovalStage)({uuid:a.uuid,userEmail:n,hodEmail:o,status:a.status,approverEmail:a.approverEmail,approverName:a.approverName,approvalTier:q});break;case"director":(0,h.directorApprovalStage)({uuid:a.uuid,userEmail:n,hodEmail:o,hrEmail:p,status:a.status,approverEmail:a.approverEmail,approverName:a.approverName});break;default:(0,i.EmailSender)({to:"geoffrey@hotpoint.co.ke",requestId:a.uuid,message:"A wrong stage was passed in the travel requisition approval workflow for this requistion",title:"Wrong stage passed to travel requisition approval workflow",role:"user"})}return{alertType:"success",alertMessage:"This requisition status has been updated successfully, you may now safely close this window"}}catch(a){return await b?.query("ROLLBACK"),console.error("Error while trying to update the status of this requisition",a),{alertType:"error",alertMessage:"An error occured while trying to update the status of this requisition"}}finally{b&&b.release()}}[e,f,g,h,i]=k.then?(await k)():k,(0,j.ensureServerEntryExports)([l]),(0,d.registerServerReference)(l,"40bbf5091a7df55d889629fc09929f9148bc121b87",null),a.s(["UpdateTravelStatus",0,l]),c()}catch(a){c(a)}},!1),24771,a=>a.a(async(b,c)=>{try{var d=a.i(67141),e=b([d]);[d]=e.then?(await e)():e,a.s([]),c()}catch(a){c(a)}},!1),58984,a=>a.a(async(b,c)=>{try{var d=a.i(24771),e=a.i(67141),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s(["40bbf5091a7df55d889629fc09929f9148bc121b87",()=>e.UpdateTravelStatus]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__10il_7u._.js.map