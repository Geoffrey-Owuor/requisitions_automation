module.exports=[66518,(a,b,c)=>{}];

//# sourceMappingURL=0ash_%28protected%29_dashboard_%28embeddings%29_staffproductpurchase_page_actions_02yttyb.js.map