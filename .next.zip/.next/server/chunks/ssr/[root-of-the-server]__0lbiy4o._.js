module.exports=[99450,a=>{a.v("/_next/static/media/hotpoint_icon.03v1kd-iqopka.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},54442,a=>{a.v("/_next/static/media/form_image.016.01-z~7ilt.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},91962,a=>{a.v("/_next/static/media/hotpoint_logo.14-vmxudg2qno.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,a=>{a.v("/_next/static/media/hotpoint_black_logo.0m41_m1z8uhzw.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},11985,a=>{a.v("/_next/static/media/it_form_image.0lz1c.hirvfk_.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},64240,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))},88947,(a,b,c)=>{b.exports=a.x("stream",()=>require("stream"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},66680,(a,b,c)=>{b.exports=a.x("node:crypto",()=>require("node:crypto"))},21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},1515,a=>{"use strict";let b={src:a.i(99450).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAMBAAQyCQI7dBQFi4YXBqF9FQaVQgsDS4MWBpxyFAaGAEILA061IAnfyyQK/MokCvm8IQnmZBIFdsgjCvarHgnTAJsbCLzKJAr7fRYGlmMRBXJbEARpTA4DWccjCvarHgnSALEfCdjDIgryVQ8EY6weCNKkHQjHVA4EY8cjCvarHwnSALIfCdrCIgnvTQ0EWJ4cCMGWGge2Ug4EYccjCverHwnSALMgCdvBIgruSQ0EU3EUBYZzFAaJkRoHscslC/2aGwi8ALMfCdzBIgruYhEFc8UjCvPNJAr+zCUK/bUgCeBEDARRAGIQBXRqEgV+NgkDPWwTBYJwEwWJZxIFfDEIAjoEAQAETr5TfppXlUsAAAAASUVORK5CYII="},c={src:a.i(54442).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYFha9ND51fmHZ9NTcntjUCRmFk4uq2xNzAI3jCztmkPycAAAAAElFTkSuQmCC"},d={src:a.i(91962).default,width:800,height:360,blurWidth:8,blurHeight:4,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAZElEQVR42k3MMQqFQBAD0GTmy+5fFe08gaUHsBPsLUUEa1vR+4MRLBx4DCQQAKglSTQgI6CHXIL8YeaHuV/ufg6p3NsQd2Xnk9FsAcmOtN5lSMXa/LJJxSazuhHfC+QzG6V6pRv3AAds+3z7uwAAAABJRU5ErkJggg=="},e={src:a.i(41535).default,width:512,height:512,blurWidth:8,blurHeight:8,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAk0lEQVR42j3QLwvCQBiA8Tf4qRQ/gSCIRaOYrComMRgEMWuy+BEsJovJrmVsgy0tbrDBxtgf9hy8W/jBcfdwd7wiIj0McMEDV4xwxwkyhocSOQLskOJvgjcK3LDGCnMNfiawEGOpG19dd4GNCDN88MICWRs4CDHVT53xRKXPi6vBBglqPfQxMcEWBwxx1Bv26JsRNFZmKZZ3JF37AAAAAElFTkSuQmCC"},f={src:a.i(11985).default,width:2172,height:339,blurWidth:8,blurHeight:1,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAIAAABsYngUAAAAIUlEQVR42mNYUlyyML9odl7RxLiU/qTM9uiUlsiU3rxyAJDeCy/80jrPAAAAAElFTkSuQmCC"};a.s(["assets",0,{hotpoint_logo:b,form_image:c,hotpoint_background:d,hotpoint_black_logo:e,it_form_image:f},"dateFormatter",0,function(a){return a?new Date(a).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"—"}],1515)},91677,a=>{"use strict";var b=a.i(7997);a.s(["default",0,()=>(0,b.jsx)("footer",{className:"relative z-10",children:(0,b.jsx)("div",{className:"mx-auto flex max-w-6xl flex-col items-center justify-center gap-6 p-6 sm:flex-row",children:(0,b.jsxs)("p",{className:"text-[13px] text-slate-500",children:["© ",new Date().getFullYear()," Hotpoint Appliances Ltd · Internal Use Only"]})})})])},46706,a=>{"use strict";var b=a.i(7997),c=a.i(91677);a.s(["default",0,({children:a})=>(0,b.jsxs)("div",{className:"flex h-full w-full flex-col",children:[(0,b.jsx)("main",{className:"mx-auto w-full max-w-7xl flex-1",children:a}),(0,b.jsx)(c.default,{})]})])},23862,a=>a.a(async(b,c)=>{try{let b=await a.y("pg-587764f78a6c7a9c");a.n(b),c()}catch(a){c(a)}},!0),66879,a=>a.a(async(b,c)=>{try{let g;var d=a.i(23862),e=b([d]);[d]=e.then?(await e)():e;let h={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function f(a,b){let c=await g.connect();try{return(await c.query(a,b)).rows}finally{c.release()}}g=new d.Pool(h),a.s(["pool",0,g,"query",0,f]),c()}catch(a){c(a)}},!1),67726,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/DashboardSidebar.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/DashboardSidebar.tsx <module evaluation>","default")},94648,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/DashboardSidebar.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/DashboardSidebar.tsx","default")},93931,a=>{"use strict";a.i(67726);var b=a.i(94648);a.n(b)},5463,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/MobileHeader.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/MobileHeader.tsx <module evaluation>","default")},6369,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/MobileHeader.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/MobileHeader.tsx","default")},47487,a=>{"use strict";a.i(5463);var b=a.i(6369);a.n(b)},5675,a=>{"use strict";var b=a.i(7997),c=a.i(93931),d=a.i(47487);a.s(["default",0,({children:a})=>(0,b.jsxs)("div",{className:"min-h-screen bg-linear-to-br from-red-950 via-red-950 to-red-900",children:[(0,b.jsx)(d.default,{}),(0,b.jsx)(c.default,{}),(0,b.jsx)("div",{id:"dashboard-wrapper",className:"layout-scrollbar fixed top-16 right-0 bottom-0 left-0 rounded-t-3xl bg-white sm:rounded-t-2xl sm:rounded-tr-none lg:top-0 lg:left-20",children:(0,b.jsx)("div",{className:"flex h-full w-full flex-col",children:a})})]})])},96719,a=>{"use strict";a.s(["UserProvider",()=>c,"useUser",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call UserProvider() from the server but UserProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx <module evaluation>","UserProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx <module evaluation>","useUser")},49390,a=>{"use strict";a.s(["UserProvider",()=>c,"useUser",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call UserProvider() from the server but UserProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx","UserProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/context/UserContext.tsx","useUser")},51016,a=>{"use strict";a.i(96719);var b=a.i(49390);a.n(b)},25489,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx <module evaluation>","default")},11152,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/NotFoundRequest.tsx","default")},44908,a=>{"use strict";a.i(25489);var b=a.i(11152);a.n(b)},36324,a=>{"use strict";var b=a.i(1515);let c="https://192.168.0.155";function d(a,b){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 35%; border-bottom: 1px solid #f7f0f0;">${a}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${b||"—"}</td>
    </tr>`}function e(a,b,c,d,f,g=!1){let h=(b||"").toLowerCase(),i="#856404",j="#fff3cd",k="1px solid #856404";return h.includes("approved")&&(i="#155724",j="#d4edda",k="1px solid #155724"),h.includes("declined")&&(i="#721c24",j="#f8d7da",k="1px solid #721c24"),`
    <div style="padding: 16px; border-bottom: ${g?"none":"1px solid #f0e6e6"}; background-color: #ffffff;">
      <table width="100%">
        <tr>
          <td>
            <p style="margin: 0; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase;">${a}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${c||"Awaiting Assignment"}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${d||"Awaiting Assignment"}</p>
          </td>
          <td style="text-align: right;">
           
            <span style="padding: 4px 10px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${i}; background-color: ${j}; border: ${k}; text-transform: uppercase;">${b||"Pending"}</span>
          </td>
        </tr>
      </table>
      ${f?`<p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 8px; border-radius: 8px; border: 1px dashed #eee;">"${f}"</p>`:""}
    </div>
  `}a.s(["TravelRequisitionTemplate",0,function({requestId:a,message:f,title:g,role:h,emailData:i,reviewLink:j,showPdfDownload:k}){let l=(0,b.dateFormatter)(i.departuredate),m=(0,b.dateFormatter)(i.returndate),n=[],o=0;return"Engineering & HVAC"===i.department&&i.engineeringjobs&&(n=i.engineeringjobs.split("\n").filter(a=>""!==a.trim()).map(a=>{let[b,c]=a.split(" - "),d=Number(c)||0;return o+=d,{title:b?.trim()||"Unknown Job",amount:d}})),`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">
        
       
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
           <table width="100%">
             <tr>
               <td style="vertical-align: middle;">
                 <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.8;">New Requisition</p>
                 <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${g}</h2>
               </td>
             </tr>
           </table>
        </div>

        <div style="padding: 30px 24px;">
          
          
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #f9e8e8;">
            <p style="margin: 0; font-size: 15px; color: #4a3a3a; line-height: 1.6;">${f}</p>
          </div>

          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Primary Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${d("Employee",i.employeename)}
              ${d("Email",i.emailaddress)}
              ${d("Department",i.department)}
              ${d("Designation",i.designation)}
              ${d("Destination",i.destination)}
              ${d("Travel Category",i.travelcategory)}
              ${d("Travel Dates",`${l} - ${m}`)}
              ${d("Transport Mode",i.modeoftransport)}
              ${d("Business Justification",i.businessjustification)}
              ${d("Cost Centre",i.costcentre)}
              ${d("Approval Tier",i.approvaltier)}
              ${d("Within Budget",i.withinbudget)}
            </table>
          </div>

          ${function(a,b){if(!a||0===a.length)return"";let c=a.map(a=>`
      <tr>
        <td style="padding-bottom: 12px; font-size: 12px; color: #7c5a5a;">${a.title}</td>
        <td style="padding-bottom: 12px; font-size: 12px; color: #1e1b1b; text-align: right; font-weight: 600;">KES ${Number(a.amount).toLocaleString()}</td>
      </tr>
    `).join("");return`
    <div style="background-color: #ffffff; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
      <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Engineering Job Allocations</p>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        ${c}
        <tr>
          <td colspan="2" style="border-top: 1px solid rgba(163,29,29,0.2); padding-top: 12px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td style="font-size: 14px; font-weight: 700; color: #a31d1d;">Allocations Subtotal</td>
                <td style="font-size: 16px; font-weight: 700; color: #1e1b1b; text-align: right;">KES ${Number(b).toLocaleString()}</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  `}(n,o)}

          <div style="background-color: #2c1a1a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Budget Summary</p>
            <table width="100%">
              <tr>
                
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Transport Cost</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.twowaytransportcost}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Other Costs</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.othercosts}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Per Diem Entitlement</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${i.perdiempolicy}</td>
              </tr>
              <tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 12px;">
                  <table width="100%">
                    <tr>
                      <td style="font-size: 14px; font-weight: 700; color: #f2d7d5;">Total Cost</td>
                      <td style="font-size: 20px; font-weight: 700; color: #ffffff; text-align: right;">KES ${i.estimatedcost}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>

          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>
          <div style="border-radius: 16px; border: 1px solid #f0e6e6; overflow: hidden;">
             ${e("Head of Department",i.hodapprovalstatus,i.hodapprover,i.hodemail,i.hodcomments)}
             ${"Tier 2"===i.approvaltier||"Tier 3"===i.approvaltier?e("Human Resources",i.hrapprovalstatus,i.hrapprover,i.hremail,i.hrcomments):""}
             ${"Tier 3"===i.approvaltier?e("Executive Director",i.directorapprovalstatus,i.directorapprover,i.directoremail,i.directorcomments,!0):""}
          </div>

          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==h?"display: inline-block;":"display: none;"}">
              <a href="${c}/travelapproval/${a}${j}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
            <div style="${k?"display: inline-block; margin-top: 10px;":"display: none;"} width: 100%;">
              <a href="${c}/travelapproval/${a}/pdfdownload" style="color: #a31d1d; font-size: 12px; font-weight: 600; text-decoration: underline; display: inline-block; margin-top: 12px;">Download PDF Summary</a>
            </div>
          </div>

        </div>

        
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #8c7474; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | Travel Requisition</p>
        </div>
      </div>
    </div>
  `}])},74561,a=>a.a(async(b,c)=>{try{var d=a.i(717),e=a.i(66879),f=a.i(36324),g=a.i(35723),h=b([e]);[e]=h.then?(await h)():h;let j=`
     SELECT 
       submitter_email AS emailaddress, 
       employee_name AS employeename, 
       employee_department AS department, 
       employee_designation AS designation, 
       travel_destination AS destination, 
       travel_departure_date AS departuredate, 
       travel_return_date AS returndate, 
       travel_category AS travelcategory,
       travel_business_justification AS businessjustification, 
       travel_mode AS modeoftransport, 
       travel_transport_cost AS twowaytransportcost, 
       travel_other_costs AS othercosts, 
       travel_per_diem AS perdiempolicy, 
       travel_total_cost AS estimatedcost, 
       travel_cost_center AS costcentre, 
       travel_within_budget AS withinbudget,
       travel_approval_tier AS approvaltier, 
       travel_hod_approval_status AS hodapprovalstatus, 
       travel_hr_approval_status AS hrapprovalstatus,
       travel_director_approval_status AS directorapprovalstatus, 
       travel_hod_approver AS hodapprover,
       travel_hod_email AS hodemail,
       travel_hod_comments AS hodcomments,
       travel_hr_approver AS hrapprover,
       travel_hr_email AS hremail,
       travel_hr_comments AS hrcomments,
       travel_director_approver AS directorapprover,
       travel_director_email AS directoremail,
       travel_director_comments AS directorcomments,
       engineering_jobs AS engineeringjobs
       FROM travel_requisitions WHERE request_id = $1
`,k=(0,d.cache)(async a=>(await (0,e.query)(j,[a]))[0]);async function i({to:a,requestId:b,message:c,title:d,role:e,reviewLink:h,showPdfDownload:j=!1}){let l=await k(b),m=(0,f.TravelRequisitionTemplate)({requestId:b,message:c,title:d,role:e,emailData:l,reviewLink:h,showPdfDownload:j});await (0,g.sendEmail)({from:process.env.EMAIL_SENDER,to:a,subject:d,html:m})}a.s(["EmailSender",0,i,"travelDataQuery",0,j]),c()}catch(a){c(a)}},!1),26758,a=>{a.v("/_next/static/media/favicon.10tnxaro9k8j3.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},38872,a=>{"use strict";let b={src:a.i(26758).default,width:48,height:48};a.s(["default",0,b])},49420,a=>{a.v("/_next/static/media/icon0.14we..jnd~v9t.svg"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},76717,a=>{"use strict";let b={src:a.i(49420).default,width:1272,height:1272};a.s(["default",0,b])},76789,a=>{a.v("/_next/static/media/apple-icon.01v_vf9.oz3x9.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},59310,a=>{"use strict";let b={src:a.i(76789).default,width:180,height:180};a.s(["default",0,b])},18202,a=>{a.v("/_next/static/media/icon1.0n~imj.jnvoz8.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},27963,a=>{"use strict";let b={src:a.i(18202).default,width:96,height:96};a.s(["default",0,b])},96593,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/RequisitionPdfModal.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/RequisitionPdfModal.tsx <module evaluation>","default")},26978,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Approvers/TravelApprovers/RequisitionPdfModal.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Approvers/TravelApprovers/RequisitionPdfModal.tsx","default")},42273,a=>{"use strict";a.i(96593);var b=a.i(26978);a.n(b)},3351,a=>{"use strict";var b=a.i(7997);a.s(["default",0,()=>(0,b.jsx)("div",{className:"relative min-h-screen overflow-x-hidden p-5",children:(0,b.jsxs)("div",{className:"relative z-10 mx-auto max-w-180 animate-pulse",children:[(0,b.jsxs)("div",{className:"mb-6 flex items-center justify-between rounded-2xl bg-white/60 px-8 py-5",children:[(0,b.jsx)("div",{className:"h-8 w-36 rounded-lg bg-gray-200"}),(0,b.jsx)("div",{className:"h-9 w-28 rounded-xl bg-gray-200"})]}),(0,b.jsxs)("div",{className:"mb-6 rounded-3xl border border-white/85 bg-white/65 px-10 py-7 backdrop-blur-2xl",children:[(0,b.jsx)("div",{className:"mb-2 h-6 w-64 rounded-lg bg-gray-200"}),(0,b.jsx)("div",{className:"h-4 w-40 rounded bg-gray-100"})]}),[1,2,3].map(a=>(0,b.jsxs)("div",{className:"mb-5 rounded-3xl border border-white/85 bg-white/65 px-10 py-7 backdrop-blur-2xl",children:[(0,b.jsx)("div",{className:"mb-5 h-4 w-36 rounded bg-gray-200"}),(0,b.jsx)("div",{className:"grid grid-cols-2 gap-5 max-sm:grid-cols-1",children:Array.from({length:4}).map((a,c)=>(0,b.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,b.jsx)("div",{className:"h-3 w-24 rounded bg-gray-100"}),(0,b.jsx)("div",{className:"h-5 w-40 rounded-lg bg-gray-200"})]},c))})]},a)),(0,b.jsxs)("div",{className:"mb-5 rounded-3xl border border-white/85 bg-white/65 px-10 py-7 backdrop-blur-2xl",children:[(0,b.jsx)("div",{className:"mb-5 h-4 w-36 rounded bg-gray-200"}),(0,b.jsx)("div",{className:"grid grid-cols-3 gap-4",children:[1,2,3].map(a=>(0,b.jsxs)("div",{className:"rounded-2xl bg-gray-100 px-5 py-5",children:[(0,b.jsx)("div",{className:"mb-2 h-3 w-20 rounded bg-gray-200"}),(0,b.jsx)("div",{className:"h-5 w-28 rounded bg-gray-200"}),(0,b.jsx)("div",{className:"mt-2 h-3 w-16 rounded bg-gray-100"})]},a))})]})]})})])},87682,a=>a.a(async(b,c)=>{try{var d=a.i(7997),e=a.i(717),f=a.i(66879),g=a.i(74561),h=a.i(44908),i=a.i(42273),j=a.i(3351),k=a.i(5675),l=a.i(46706),m=a.i(51016),n=b([f,g]);[f,g]=n.then?(await n)():n;let o=async({params:a})=>{let{uuid:b}=await a;if(!b)return(0,d.jsx)(h.default,{});let c=await (0,f.query)(g.travelDataQuery,[b]);if(0===c.length)return(0,d.jsx)(h.default,{});let n=c[0];return(0,d.jsx)(m.UserProvider,{user:{username:"Guest Account",email:"noreply@hotpoint.co.ke",roles:["guest"]},children:(0,d.jsx)(k.default,{children:(0,d.jsx)(l.default,{children:(0,d.jsx)(e.Suspense,{fallback:(0,d.jsx)(j.default,{}),children:(0,d.jsx)(i.default,{pdfData:n})})})})})};a.s(["default",0,o,"metadata",0,{title:"Travel Requisition Pdf",description:"Download the travel requisition pdf"}]),c()}catch(a){c(a)}},!1),84584,a=>{a.n(a.i(87682))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0lbiy4o._.js.map