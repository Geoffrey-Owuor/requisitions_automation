module.exports=[75644,e=>{"use strict";var t=e.i(71917);let r="https://192.168.0.155";function a(e,t){return`
    <tr>
      <td style="padding: 10px 0; font-size: 12px; color: #5a3a3a; width: 35%; border-bottom: 1px solid #f7f0f0;">${e}</td>
      <td style="padding: 10px 0; font-size: 13px; color: #1a0f0f; font-weight: 500; border-bottom: 1px solid #f7f0f0;">${t||"—"}</td>
    </tr>`}function o(e,t,r,a,i,n=!1){let s=(t||"").toLowerCase(),l="#856404",d="#fff3cd",p="1px solid #856404";return s.includes("approved")&&(l="#155724",d="#d4edda",p="1px solid #155724"),s.includes("declined")&&(l="#721c24",d="#f8d7da",p="1px solid #721c24"),`
    <div style="padding: 16px; border-bottom: ${n?"none":"1px solid #f0e6e6"}; background-color: #ffffff;">
      <table width="100%">
        <tr>
          <td>
            <p style="margin: 0; font-size: 10px; font-weight: 800; color: #5a3a3a; text-transform: uppercase;">${e}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${r||"Awaiting Assignment"}</p>
            <p style="margin: 2px 0 0; font-size: 13px; color: #1a0f0f; font-weight: 600;">${a||"Awaiting Assignment"}</p>
          </td>
          <td style="text-align: right;">
           
            <span style="padding: 4px 10px; border-radius: 8px; font-size: 10px; font-weight: 800; color: ${l}; background-color: ${d}; border: ${p}; text-transform: uppercase;">${t||"Pending"}</span>
          </td>
        </tr>
      </table>
      ${i?`<p style="margin: 8px 0 0; font-size: 12px; color: #5a3a3a; font-style: italic; background-color: #ffffff; padding: 8px; border-radius: 8px; border: 1px dashed #eee;">"${i}"</p>`:""}
    </div>
  `}e.s(["TravelRequisitionTemplate",0,function({requestId:e,message:i,title:n,role:s,emailData:l,reviewLink:d,showPdfDownload:p}){let u=(0,t.dateFormatter)(l.departuredate),c=(0,t.dateFormatter)(l.returndate),f=[],m=0;return"Engineering & HVAC"===l.department&&l.engineeringjobs&&(f=l.engineeringjobs.split("\n").filter(e=>""!==e.trim()).map(e=>{let[t,r]=e.split(" - "),a=Number(r)||0;return m+=a,{title:t?.trim()||"Unknown Job",amount:a}})),`
    <div style="background-color: #fcfafb; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(163,29,29,0.08); border: 1px solid #f2eaea;">
        
       
        <div style="background-color: #a31d1d; padding: 24px 30px; border-bottom: 4px solid #f2d7d5;">
           <table width="100%">
             <tr>
               <td style="vertical-align: middle;">
                 <p style="margin: 0; font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #f2d7d5; opacity: 0.8;">New Requisition</p>
                 <h2 style="margin: 4px 0 0; font-size: 20px; color: #ffffff; font-weight: 600;">${n}</h2>
               </td>
             </tr>
           </table>
        </div>

        <div style="padding: 30px 24px;">
          
          
          <div style="background-color: #ffffff; border-radius: 16px; padding: 18px 20px; margin-bottom: 24px; border: 1px solid #f9e8e8;">
            <p style="margin: 0; font-size: 15px; color: #4a3a3a; line-height: 1.6;">${i}</p>
          </div>

          <div style="margin-bottom: 24px;">
            <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Primary Information</p>
            <table width="100%" style="border-collapse: collapse;">
              ${a("Employee",l.employeename)}
              ${a("Email",l.emailaddress)}
              ${a("Department",l.department)}
              ${a("Designation",l.designation)}
              ${a("Destination",l.destination)}
              ${a("Travel Category",l.travelcategory)}
              ${a("Travel Dates",`${u} - ${c}`)}
              ${a("Transport Mode",l.modeoftransport)}
              ${a("Business Justification",l.businessjustification)}
              ${a("Cost Centre",l.costcentre)}
              ${a("Approval Tier",l.approvaltier)}
              ${a("Within Budget",l.withinbudget)}
            </table>
          </div>

          ${function(e,t){if(!e||0===e.length)return"";let r=e.map(e=>`
      <tr>
        <td style="padding-bottom: 12px; font-size: 12px; color: #7c5a5a;">${e.title}</td>
        <td style="padding-bottom: 12px; font-size: 12px; color: #1e1b1b; text-align: right; font-weight: 600;">KES ${Number(e.amount).toLocaleString()}</td>
      </tr>
    `).join("");return`
    <div style="background-color: #ffffff; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
      <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Engineering Job Allocations</p>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        ${r}
        <tr>
          <td colspan="2" style="border-top: 1px solid rgba(163,29,29,0.2); padding-top: 12px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td style="font-size: 14px; font-weight: 700; color: #a31d1d;">Allocations Subtotal</td>
                <td style="font-size: 16px; font-weight: 700; color: #1e1b1b; text-align: right;">KES ${Number(t).toLocaleString()}</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  `}(f,m)}

          <div style="background-color: #2c1a1a; border-radius: 20px; padding: 24px; margin-bottom: 24px; border: 1px solid rgba(163,29,29,0.2);">
            <p style="margin: 0 0 16px; font-size: 10px; font-weight: 800; color: #a31d1d; text-transform: uppercase; letter-spacing: 2px;">Budget Summary</p>
            <table width="100%">
              <tr>
                
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Transport Cost</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${l.twowaytransportcost}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Other Costs</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${l.othercosts}</td>
              </tr>
              <tr>
                <td style="padding-bottom: 12px; font-size: 12px; color: #c9a8a8;">Per Diem Entitlement</td>
                <td style="padding-bottom: 12px; font-size: 12px; color: #ffffff; text-align: right; font-weight: 600;">KES ${l.perdiempolicy}</td>
              </tr>
              <tr>
                <td colspan="2" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 12px;">
                  <table width="100%">
                    <tr>
                      <td style="font-size: 14px; font-weight: 700; color: #f2d7d5;">Total Cost</td>
                      <td style="font-size: 20px; font-weight: 700; color: #ffffff; text-align: right;">KES ${l.estimatedcost}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>

          <p style="font-size: 11px; font-weight: 700; color: #a31d1d; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 12px;">Approval Workflow</p>
          <div style="border-radius: 16px; border: 1px solid #f0e6e6; overflow: hidden;">
             ${o("Head of Department",l.hodapprovalstatus,l.hodapprover,l.hodemail,l.hodcomments)}
             ${"Tier 2"===l.approvaltier||"Tier 3"===l.approvaltier?o("Human Resources",l.hrapprovalstatus,l.hrapprover,l.hremail,l.hrcomments):""}
             ${"Tier 3"===l.approvaltier?o("Executive Director",l.directorapprovalstatus,l.directorapprover,l.directoremail,l.directorcomments,!0):""}
          </div>

          <div style="margin-top: 32px; text-align: center;">
            <div style="${"user"!==s?"display: inline-block;":"display: none;"}">
              <a href="${r}/travelapproval/${e}${d}" style="background-color: #a31d1d; color: #ffffff; padding: 14px 36px; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 13px; display: inline-block;">Review Requisition</a>
            </div>
            <div style="${p?"display: inline-block; margin-top: 10px;":"display: none;"} width: 100%;">
              <a href="${r}/travelapproval/${e}/pdfdownload" style="color: #a31d1d; font-size: 12px; font-weight: 600; text-decoration: underline; display: inline-block; margin-top: 12px;">Download PDF Summary</a>
            </div>
          </div>

        </div>

        
        <div style="background-color: #ffffff; padding: 20px; text-align: center; border-top: 1px solid #f2eaea;">
          <p style="margin: 0; font-size: 10px; color: #8c7474; letter-spacing: 1px;">&copy; ${new Date().getFullYear()} Hotpoint Appliances Ltd. | Travel Requisition</p>
        </div>
      </div>
    </div>
  `}])},72291,e=>e.a(async(t,r)=>{try{var a=e.i(47540),o=e.i(62294),i=e.i(75644),n=e.i(44732),s=t([o]);[o]=s.then?(await s)():s;let d=`
     SELECT 
       submitter_email AS emailaddress, 
       employee_name AS employeename, 
       employee_department AS department, 
       employee_designation AS designation, 
       travel_destination AS destination, 
       travel_departure_date AS departuredate, 
       travel_return_date AS returndate, 
       travel_category AS travelcategory,
       travel_business_justification AS businessjustification, 
       travel_mode AS modeoftransport, 
       travel_transport_cost AS twowaytransportcost, 
       travel_other_costs AS othercosts, 
       travel_per_diem AS perdiempolicy, 
       travel_total_cost AS estimatedcost, 
       travel_cost_center AS costcentre, 
       travel_within_budget AS withinbudget,
       travel_approval_tier AS approvaltier, 
       travel_hod_approval_status AS hodapprovalstatus, 
       travel_hr_approval_status AS hrapprovalstatus,
       travel_director_approval_status AS directorapprovalstatus, 
       travel_hod_approver AS hodapprover,
       travel_hod_email AS hodemail,
       travel_hod_comments AS hodcomments,
       travel_hr_approver AS hrapprover,
       travel_hr_email AS hremail,
       travel_hr_comments AS hrcomments,
       travel_director_approver AS directorapprover,
       travel_director_email AS directoremail,
       travel_director_comments AS directorcomments,
       engineering_jobs AS engineeringjobs
       FROM travel_requisitions WHERE request_id = $1
`,p=(0,a.cache)(async e=>(await (0,o.query)(d,[e]))[0]);async function l({to:e,requestId:t,message:r,title:a,role:o,reviewLink:s,showPdfDownload:d=!1}){let u=await p(t),c=(0,i.TravelRequisitionTemplate)({requestId:t,message:r,title:a,role:o,emailData:u,reviewLink:s,showPdfDownload:d});await (0,n.sendEmail)({from:process.env.EMAIL_SENDER,to:e,subject:a,html:c})}e.s(["EmailSender",0,l]),r()}catch(e){r(e)}},!1),8145,e=>e.a(async(t,r)=>{try{var a=e.i(89171),o=e.i(25725),i=e.i(62294),n=e.i(72291),s=t([o,i,n]);async function l(e){let t=await (0,o.loadHrArray)();try{let{formData:r,totalCost:o,approvalTier:s,submittedBy:l}=await e.json(),{name:d,email:p}=l;if(!d||!p)return a.NextResponse.json({message:"Cannot verify the user trying to make this requisition"},{status:401});let{employeeName:u,department:c,designation:f,hodApprover:m,destination:v,departureDate:g,returnDate:h,travelCategory:x,justification:b,travelMode:_,transportCost:y,otherCost:w,perDiem:R,costCentre:A,withinBudget:$,engineeringJobs:E}=r;if(Object.entries(r).some(([e,t])=>"engineeringJobs"!==e&&(null==t||""===t))||"Engineering & HVAC"===c&&!E)return a.NextResponse.json({message:"Your requisition is missing some required form fields"},{status:400});let S=await (0,i.query)(`
      SELECT hod_uuid AS uuid, 
      hod_email AS email
      FROM hod_array WHERE hod_name = $1 LIMIT 1
      `,[m]);if(0===S.length)return a.NextResponse.json({message:"Could not find the selected HOD approver in current approval workflow, contact the admin for support"},{status:404});let q=S[0].uuid,T=S[0].email,C=`
    INSERT INTO travel_requisitions
    (submitter_email, submitter_name, employee_name, employee_department, employee_designation, 
    travel_destination, travel_departure_date, travel_return_date, travel_category,
    travel_business_justification, travel_mode, travel_transport_cost,
    travel_other_costs, travel_per_diem, travel_total_cost, travel_cost_center, travel_within_budget,
    travel_approval_tier, travel_hod_approval_status, travel_hr_approval_status,
    travel_director_approval_status, travel_hod_approver, travel_hod_email, engineering_jobs)
    VALUES 
    ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
    $11, $12, $13, $14, $15, $16, $17, $18,
    $19, $20, $21, $22, $23, $24) RETURNING request_id
    `,N=(await (0,i.query)(C,[p,d,u,c,f,v,g,h,x,b,_,y,w,R,o,A,$,s,"pending","Tier 2"===s||"Tier 3"===s?"pending":"N/A","Tier 3"===s?"pending":"N/A",m,T,E||null]))[0].request_id;if(T===p){let e=`
        UPDATE travel_requisitions
        SET 
        travel_hod_approval_date = CURRENT_TIMESTAMP,
        travel_hod_email = $1,
        travel_hod_approval_status = $2,
        travel_hod_comments = $3
        WHERE request_id = $4
        `,r=[T,"approved","Automatic HOD Approval",N];await (0,i.query)(e,r),"Tier 1"===s?(0,n.EmailSender)({to:p,requestId:N,message:"This is an automatic HOD approval for your travel requisition",title:"Final Update: Travel Requisition Approved",role:"user",showPdfDownload:!0}):(t.forEach(e=>{(0,n.EmailSender)({to:e.email,requestId:N,message:"A new travel requisition has been submitted and requires your approval",title:"Action Required: New Travel Requisition",role:"HR",reviewLink:`?token=${e.uuid}&stage=hr`})}),(0,n.EmailSender)({to:p,requestId:N,message:"Your travel requisition has been successfully submitted and forwarded to HR for approval",title:"Update: Travel requisition submitted successfully",role:"user"}))}else(0,n.EmailSender)({to:T,requestId:N,message:"A new travel requisition has been submitted and requires your approval",title:"Action Required: Travel Requisition Review",role:"HOD",reviewLink:`?token=${q}&stage=hod`}),(0,n.EmailSender)({to:p,requestId:N,message:"Your travel requisition has been submitted successfully and forwarded to the HOD for approval.",title:"Update: Travel Requisition Successfully Submitted",role:"user"});return a.NextResponse.json({message:"Your travel requisition has been submitted successfully, you will receive a confirmation email shortly"},{status:200})}catch(e){return console.error("Error while trying to submit the requisition",e),a.NextResponse.json({message:"An error occurred while trying to submit this requisition"},{status:500})}}[o,i,n]=s.then?(await s)():s,e.s(["POST",0,l]),r()}catch(e){r(e)}},!1),63273,e=>e.a(async(t,r)=>{try{var a=e.i(47909),o=e.i(74017),i=e.i(96250),n=e.i(59756),s=e.i(61916),l=e.i(74677),d=e.i(69741),p=e.i(16795),u=e.i(87718),c=e.i(95169),f=e.i(47587),m=e.i(66012),v=e.i(70101),g=e.i(26937),h=e.i(10372),x=e.i(93695);e.i(52474);var b=e.i(220),_=e.i(8145),y=t([_]);[_]=y.then?(await y)():y;let R=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/travelrequisition/submitrequisition/route",pathname:"/api/travelrequisition/submitrequisition",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/travelrequisition/submitrequisition/route.ts",nextConfigOutput:"",userland:_,...{}}),{workAsyncStorage:A,workUnitAsyncStorage:$,serverHooks:E}=R;async function w(e,t,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),R.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/travelrequisition/submitrequisition/route";a=a.replace(/\/index$/,"")||"/";let i=await R.prepare(e,t,{srcPage:a,multiZoneDraftMode:!1});if(!i)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:_,deploymentId:y,params:w,nextConfig:A,parsedUrl:$,isDraftMode:E,prerenderManifest:S,routerServerContext:q,isOnDemandRevalidate:T,revalidateOnlyGenerated:C,resolvedPathname:N,clientReferenceManifest:k,serverActionsManifest:H}=i,O=(0,d.normalizeAppPath)(a),P=!!(S.dynamicRoutes[O]||S.routes[N]),D=async()=>((null==q?void 0:q.render404)?await q.render404(e,t,$,!1):t.end("This page could not be found"),null);if(P&&!E){let e=!!S.routes[N],t=S.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(A.adapterPath)return await D();throw new x.NoFallbackError}}let z=null;!P||R.isDev||E||(z=N,z="/index"===z?"/":z);let I=!0===R.isDev||!P,j=P&&!I;H&&k&&(0,l.setManifestsSingleton)({page:a,clientReferenceManifest:k,serverActionsManifest:H});let U=e.method||"GET",M=(0,s.getTracer)(),F=M.getActiveScopeSpan(),L=!!(null==q?void 0:q.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),B=(0,n.getRequestMeta)(e,"incrementalCache")||await R.getIncrementalCache(e,A,S,K);null==B||B.resetRequestCache(),globalThis.__incrementalCache=B;let W={params:w,previewProps:S.preview,renderOpts:{experimental:{authInterrupts:!!A.experimental.authInterrupts},cacheComponents:!!A.cacheComponents,supportsDynamicResponse:I,incrementalCache:B,cacheLifeProfiles:A.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,o)=>R.onRequestError(e,t,a,o,q)},sharedContext:{buildId:_,deploymentId:y}},V=new p.NodeNextRequest(e),Y=new p.NodeNextResponse(t),G=u.NextRequestAdapter.fromNodeNextRequest(V,(0,u.signalFromNodeResponse)(t));try{let i,n=async e=>R.handle(G,W).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=M.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=r.get("next.route");if(o){let t=`${U} ${o}`;e.setAttributes({"next.route":o,"http.route":o,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",o),i.updateName(t))}else e.updateName(`${U} ${a}`)}),l=async i=>{var s,l;let d=async({previousCacheEntry:o})=>{try{if(!K&&T&&C&&!o)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await n(i);e.fetchMetrics=W.renderOpts.fetchMetrics;let s=W.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let l=W.renderOpts.collectedTags;if(!P)return await (0,m.sendResponse)(V,Y,a,W.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,v.toNodeOutgoingHttpHeaders)(a.headers);l&&(t[h.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==W.renderOpts.collectedRevalidate&&!(W.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&W.renderOpts.collectedRevalidate,o=void 0===W.renderOpts.collectedExpire||W.renderOpts.collectedExpire>=h.INFINITE_CACHE?void 0:W.renderOpts.collectedExpire;return{value:{kind:b.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:o}}}}catch(t){throw(null==o?void 0:o.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:a,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:T})},!1,q),t}},p=await R.handleResponse({req:e,nextConfig:A,cacheKey:z,routeKind:o.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:T,revalidateOnlyGenerated:C,responseGenerator:d,waitUntil:r.waitUntil,isMinimalMode:K});if(!P)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==b.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",T?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),E&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,v.fromNodeOutgoingHttpHeaders)(p.value.headers);return K&&P||u.delete(h.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,g.getCacheControlHeader)(p.cacheControl)),await (0,m.sendResponse)(V,Y,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};L&&F?await l(F):(i=M.getActiveScopeSpan(),await M.withPropagatedContext(e.headers,()=>M.trace(c.BaseServerSpan.handleRequest,{spanName:`${U} ${a}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},l),void 0,!L))}catch(t){if(t instanceof x.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:T})},!1,q),P)throw t;return await (0,m.sendResponse)(V,Y,new Response(null,{status:500})),null}}e.s(["handler",0,w,"patchFetch",0,function(){return(0,i.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:$})},"routeModule",0,R,"serverHooks",0,E,"workAsyncStorage",0,A,"workUnitAsyncStorage",0,$]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=_09ngn19._.js.map