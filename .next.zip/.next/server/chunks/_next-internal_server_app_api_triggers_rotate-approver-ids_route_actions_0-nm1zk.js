module.exports=[52124,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_triggers_rotate-approver-ids_route_actions_0-nm1zk.js.map