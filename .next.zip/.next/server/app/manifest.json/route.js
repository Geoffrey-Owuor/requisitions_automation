var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.json/route.js")
R.c("server/chunks/[root-of-the-server]__06~p3ee._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_manifest_json_route_actions_0xzkznv.js")
R.m(88739)
module.exports=R.m(88739).exports
