var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon1.png/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0j3i5m~.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_icon1_png_route_actions_00emlzz.js")
R.m(86728)
module.exports=R.m(86728).exports
