var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check-headers/route.js")
R.c("server/chunks/[root-of-the-server]__0bz3.ye._.js")
R.c("server/chunks/node_modules_next_0p7zs5o._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_check-headers_route_actions_0os2743.js")
R.m(76209)
module.exports=R.m(76209).exports
