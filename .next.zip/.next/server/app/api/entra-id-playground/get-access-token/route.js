var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/entra-id-playground/get-access-token/route.js")
R.c("server/chunks/[root-of-the-server]__02mih13._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/0zjb_server_app_api_entra-id-playground_get-access-token_route_actions_13s.83v.js")
R.m(92552)
module.exports=R.m(92552).exports
