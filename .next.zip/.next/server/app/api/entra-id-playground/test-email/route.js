var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/entra-id-playground/test-email/route.js")
R.c("server/chunks/[root-of-the-server]__1047v_8._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/0zjb_server_app_api_entra-id-playground_test-email_route_actions_0qsb-~u.js")
R.m(4491)
module.exports=R.m(4491).exports
