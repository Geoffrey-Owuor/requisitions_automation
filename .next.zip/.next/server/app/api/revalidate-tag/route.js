var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate-tag/route.js")
R.c("server/chunks/[root-of-the-server]__0cm~kks._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_0je0vb~._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate-tag_route_actions_0h-l4-c.js")
R.m(73430)
module.exports=R.m(73430).exports
