var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/itrequisition/requisitions-export/route.js")
R.c("server/chunks/[root-of-the-server]__01kzd4-._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0rbv-tv._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/0zjb_server_app_api_itrequisition_requisitions-export_route_actions_0.g2s12.js")
R.m(8126)
module.exports=R.m(8126).exports
