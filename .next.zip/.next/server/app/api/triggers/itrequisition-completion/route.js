var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/triggers/itrequisition-completion/route.js")
R.c("server/chunks/[root-of-the-server]__0nguhmc._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/0zjb_server_app_api_triggers_itrequisition-completion_route_actions_0-an-zj.js")
R.m(55098)
module.exports=R.m(55098).exports
