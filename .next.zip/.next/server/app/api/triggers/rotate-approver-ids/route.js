var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/triggers/rotate-approver-ids/route.js")
R.c("server/chunks/[root-of-the-server]__13ot97t._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_triggers_rotate-approver-ids_route_actions_0-nm1zk.js")
R.m(51415)
module.exports=R.m(51415).exports
