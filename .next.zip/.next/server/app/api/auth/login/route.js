var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__08s2s54._.js")
R.c("server/chunks/node_modules_next_0p7zs5o._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_arctic_dist_index_0lhdttr.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_0zukc38.js")
R.m(74378)
module.exports=R.m(74378).exports
