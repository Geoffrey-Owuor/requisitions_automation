var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0o6bcxn._.js")
R.c("server/chunks/lib_session_ts_0xw21.p._.js")
R.c("server/chunks/node_modules_next_0p7zs5o._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0fm~3ij.js")
R.m(43488)
module.exports=R.m(43488).exports
