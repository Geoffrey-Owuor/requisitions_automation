var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0.i1igk._.js")
R.c("server/chunks/lib_session_ts_0xw21.p._.js")
R.c("server/chunks/node_modules_next_0p7zs5o._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_arctic_dist_index_0lhdttr.js")
R.c("server/chunks/_next-internal_server_app_api_auth_callback_route_actions_0hq4xgn.js")
R.m(65771)
module.exports=R.m(65771).exports
