1:"$Sreact.fragment"
2:I[100,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[77022,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:I[39756,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
5:I[37457,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
6:I[36768,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/01vwm8d4dj36..js"],"default"]
:HL["/_next/static/chunks/09zs17xeqmhwr.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/09zs17xeqmhwr.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/10b2v0kj__hu1.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0d3shmwh5_nmn.js","async":true}]],["$","html",null,{"lang":"en","data-scroll-behavior":"smooth","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable antialiased","children":[["$","head",null,{"children":["$","meta",null,{"name":"apple-mobile-web-app-title","content":"Requisition"}]}],["$","body",null,{"className":"flex min-h-screen flex-col bg-[#fafafa]","children":[["$","$L2",null,{}],["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[["$","$L6",null,{}],[]]}]}]]}]]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"IBxFrG6t2ImqbkpQjbRfg"}
