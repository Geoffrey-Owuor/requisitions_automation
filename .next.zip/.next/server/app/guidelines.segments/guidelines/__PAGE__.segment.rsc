1:"$Sreact.fragment"
2:I[60607,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/01ku5k_nz-e5y.js","/_next/static/chunks/14cdbd55n2kdk.js"],"default"]
3:I[97367,["/_next/static/chunks/10b2v0kj__hu1.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/01ku5k_nz-e5y.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/14cdbd55n2kdk.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"IBxFrG6t2ImqbkpQjbRfg"}
5:null
