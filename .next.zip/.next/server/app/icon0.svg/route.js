var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon0.svg/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_04fl.ly.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_icon0_svg_route_actions_0_.ngbp.js")
R.m(80619)
module.exports=R.m(80619).exports
