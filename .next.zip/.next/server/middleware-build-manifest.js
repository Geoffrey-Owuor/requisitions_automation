globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/IBxFrG6t2ImqbkpQjbRfg/_buildManifest.js",
    "static/IBxFrG6t2ImqbkpQjbRfg/_ssgManifest.js",
    "static/IBxFrG6t2ImqbkpQjbRfg/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/16fce0~0kfr7_.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0bw2yxpslzlb7.js",
    "static/chunks/turbopack-0hr2skaqqvmg7.js"
  ]
};
